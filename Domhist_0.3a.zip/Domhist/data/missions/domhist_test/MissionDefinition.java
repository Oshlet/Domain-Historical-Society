package data.missions.domhist_test;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.impl.campaign.ids.Skills;

public class MissionDefinition implements MissionDefinitionPlugin {

  @Override
	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "DHS", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "ISS", FleetGoal.ATTACK, true);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Domain Historical Society, testing.");
		api.setFleetTagline(FleetSide.ENEMY, "AN ENEMY! QUICK KILL IT!.");
		
		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Testing ships.");
		
		// Set up the player's fleet.
		
		api.addToFleet(FleetSide.PLAYER, "domhist_paddington_stk", FleetMemberType.SHIP, "Olright Guvnah!", true);
		
		api.addToFleet(FleetSide.PLAYER, "domhist_picadilly_ass", FleetMemberType.SHIP, "Insert Witty Name Here", false);
		
		api.addToFleet(FleetSide.PLAYER, "domhist_sunder_dh_sup", FleetMemberType.SHIP, "Test 0", false);
		
		api.addToFleet(FleetSide.PLAYER, "domhist_kilburn_std", FleetMemberType.SHIP, "Test 1", false);
		
		/*
		FleetMemberAPI chainTest = api.addToFleet(FleetSide.PLAYER, "domhist_kilburn_std", FleetMemberType.SHIP, "Test 1+", false);
		PersonAPI domhist_testCap = Global.getSector().getFaction("independent").createRandomPerson(FullName.Gender.FEMALE);
		domhist_testCap.setId("domhist_testCaptain");
		domhist_testCap.setFaction("independent");
		domhist_testCap.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 1);
		domhist_testCap.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 2);
		domhist_testCap.getStats().setLevel(2);
        chainTest.setCaptain(domhist_testCap);
        */
		// for testing multi chain-home interactions, and SysEx
        
		api.addToFleet(FleetSide.PLAYER, "domhist_charing_cross_brwl", FleetMemberType.SHIP, "Test 2", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_wembley_bal", FleetMemberType.SHIP, "Test 3", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_wembleynorth_sup", FleetMemberType.SHIP, "Test 4", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_falcon_dh_bal", FleetMemberType.SHIP, "Test 5", false);
		
		api.addToFleet(FleetSide.PLAYER, "domhist_harlesden_sup", FleetMemberType.SHIP, "Test 6", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_edgeware_ass", FleetMemberType.SHIP, "Test 7", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_enforcer_dh_ass", FleetMemberType.SHIP, "Test 8", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_mule_dh_sup", FleetMemberType.SHIP, "Test 9", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_harrow_stk", FleetMemberType.SHIP, "Test 10", false);
		
		api.addToFleet(FleetSide.PLAYER, "domhist_oxford_circus_brwl", FleetMemberType.SHIP, "Test 11", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_stonebridge_stk", FleetMemberType.SHIP, "Test 12", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_wealdstone_ass", FleetMemberType.SHIP, "Test 13", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_kenton_ass", FleetMemberType.SHIP, "Test 14", false);
		
		/*
		api.addToFleet(FleetSide.PLAYER, "domhist_brawler_Assault", FleetMemberType.SHIP, "VO Test 1", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_brawler_Support", FleetMemberType.SHIP, "VO Test 2", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_cerberus_Hardened", FleetMemberType.SHIP, "VO Test 3", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_cerberus_Shielded", FleetMemberType.SHIP, "VO Test 4", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_cerberus_Standard", FleetMemberType.SHIP, "VO Test 5", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_enforcer_Assault", FleetMemberType.SHIP, "VO Test 6", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_enforcer_Fighter_Support", FleetMemberType.SHIP, "VO Test 7", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_eradicator_Assault", FleetMemberType.SHIP, "VO Test 8", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_eradicator_Fighter_Support", FleetMemberType.SHIP, "VO Test 9", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_lasher_Assault", FleetMemberType.SHIP, "VO Test 10", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_lasher_Strike", FleetMemberType.SHIP, "VO Test 11", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_manticore_Assault", FleetMemberType.SHIP, "VO Test 12", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_manticore_Support", FleetMemberType.SHIP, "VO Test 13", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_vanguard_Attack", FleetMemberType.SHIP, "VO Test 14", false);
		api.addToFleet(FleetSide.PLAYER, "domhist_vanguard_Strike", FleetMemberType.SHIP, "VO Test 15", false);
		*/
		
		
		
		// Set up the enemy fleet.
		api.addToFleet(FleetSide.ENEMY, "champion_Support", FleetMemberType.SHIP, "Target 1", false);
		api.addToFleet(FleetSide.ENEMY, "eagle_Balanced", FleetMemberType.SHIP, "Target 2", false);
		api.addToFleet(FleetSide.ENEMY, "hammerhead_Balanced", FleetMemberType.SHIP, "Target 3", false);
		api.addToFleet(FleetSide.ENEMY, "hammerhead_Balanced", FleetMemberType.SHIP, "Target 4", false);
		api.addToFleet(FleetSide.ENEMY, "brawler_Assault", FleetMemberType.SHIP, "Target 5", false);
		api.addToFleet(FleetSide.ENEMY, "brawler_Assault", FleetMemberType.SHIP, "Target 6", false);

		api.defeatOnShipLoss("Insert Witty Name Here");
		
		// Set up the map.
		float width = 12000f;
		float height = 12000f;
		api.initMap((float)-width/2f, (float)width/2f, (float)-height/2f, (float)height/2f);
		
		float minX = -width/2;
		float minY = -height/2;
		
		// Add an asteroid field
		api.addAsteroidField(minX, minY + height / 2, 0, 8000f,
							 20f, 70f, 100);
		
	}

}
