package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class domhist_compact_hangar extends BaseHullMod {
  
	public static final float COST_MALUS = 100f;

    public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {

		stats.getDynamic().getMod(Stats.BOMBER_COST_MOD).modifyPercent(id, COST_MALUS);
    }
    
    public String getDescriptionParam(int index, HullSize hullSize) {
      
        if (index == 0) return "Bombers";
        if (index == 1) return (int) COST_MALUS + "%";
        return null;
    }

	@Override
	public boolean affectsOPCosts() {
		return true;
	}
}
