package data.hullmods;

import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.skills.BaseSkillEffectDescription;

import java.awt.Color;

public class CHM_domhist extends BaseHullMod {
    
    public static final int CAP_BONUS = 10;

    @Override
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
    	
		MutableCharacterStatsAPI cStats = BaseSkillEffectDescription.getCommanderStats(stats);
		float flux = CAP_BONUS * stats.getVariant().computeWeaponOPCost(cStats);
		stats.getFluxCapacity().modifyFlat(id, flux);
	}
    
    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
    	if (index == 0) return "" + CAP_BONUS + "";
        return null;
    }
    
    
	// lets give the CHM a cool border :)))
    @Override
    public Color getBorderColor() {
        return new Color(191,46,46,255); //189,42,30,150
    }
}
