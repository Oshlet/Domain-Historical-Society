package data.hullmods;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.loading.WeaponSlotAPI;

public class domhist_paradeFlares extends BaseHullMod {

    public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {
    }
    
	public void advanceInCombat(ShipAPI ship, float amount){
		
		CombatEngineAPI engine = Global.getCombatEngine();
		
		ShipSpecificData info = (ShipSpecificData) engine.getCustomData().get("PARADE_DATA_KEY" + ship.getId());
        if (info == null) {
            info = new ShipSpecificData();
        }
		
		if (ship.getSystem().isActive()) {
			float timer = amount * ship.getSystem().getEffectLevel();
			info.FLARE_DELAY -= timer;
			while (info.FLARE_DELAY <= 0f) {
				info.FLARE_DELAY += 0.4f;
				
				for (WeaponSlotAPI weapon : ship.getHullSpec().getAllWeaponSlotsCopy()) {
					if (weapon.isSystemSlot()) {
						Global.getCombatEngine().spawnProjectile(ship,
								null,
								"flarelauncher21",
								weapon.computePosition(ship),
								weapon.getAngle() + ship.getFacing(),
								ship.getVelocity());
	      
						float randomSize1 = MathUtils.getRandomNumberInRange(25f, 35f);
						float randomSize2 = MathUtils.getRandomNumberInRange(35f, 45f);
						
						Vector2f smokeVel = new Vector2f();
						smokeVel.x += ship.getVelocity().x;
						smokeVel.y += ship.getVelocity().y;
						
						smokeVel.x *= MathUtils.getRandomNumberInRange(0.4f, 0.5f);
						smokeVel.y *= MathUtils.getRandomNumberInRange(0.4f, 0.5f);
						
						engine.addSwirlyNebulaParticle(weapon.computePosition(ship),
								smokeVel,
								randomSize1, //size
								2.0f, //end mult
								0.5f, //ramp fraction
								0.5f, //full bright fraction
								0.9f, //duration
								new Color(115,105,100,70),
								true);

						engine.addNebulaParticle(weapon.computePosition(ship),
								smokeVel,
								randomSize2, //size
								2.2f, //end mult
								0.5f, //ramp fraction
								0.75f, //full bright fraction
								1.1f, //duration
								new Color(115,105,100,95),
								true);      
					}
				}
				Global.getSoundPlayer().playSound("system_flare_launcher_active", 1f, 1f, ship.getLocation(), ship.getVelocity());
			}
		} else {
			info.FLARE_DELAY = 0f;
		}
		engine.getCustomData().put("PARADE_DATA_KEY" + ship.getId(), info);
	}
	
    public String getDescriptionParam(int index, HullSize hullSize) {
        return null;
    }
    
    private class ShipSpecificData {
    	private float FLARE_DELAY = 0f; 
    }
    
}
