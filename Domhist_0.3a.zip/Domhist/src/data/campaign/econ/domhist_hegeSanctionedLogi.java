package data.campaign.econ;

import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class domhist_hegeSanctionedLogi extends BaseHazardCondition {

	public static final float ACCESS_BONUS = 10f;

    @Override
    public void apply(String id) {
        super.apply(id);
        if (market.getFactionId() == "domhist") {
    		market.getAccessibilityMod().modifyFlat(id, ACCESS_BONUS/100f, "Hegemony-Sanctioned Logistics");
        }
    }

    public void advance(String id) {
    	if (market.getFactionId() != "domhist") {
    		market.getAccessibilityMod().unmodifyFlat(id);
        }
    }
    
    @Override
    public void unapply(String id) {
        super.unapply(id);
		market.getAccessibilityMod().unmodifyFlat(id);
    }
    
    @Override
    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
        super.createTooltipAfterDescription(tooltip, expanded);
		
		tooltip.addPara("%s accessibility if under DHS ownership.", 
						10f, Misc.getHighlightColor(),
						"+" + (int)ACCESS_BONUS + "%");
    }
}
