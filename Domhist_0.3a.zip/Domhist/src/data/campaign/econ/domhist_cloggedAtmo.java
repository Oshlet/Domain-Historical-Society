package data.campaign.econ;

import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;


public class domhist_cloggedAtmo extends BaseHazardCondition {
	
    public static float HAZARD_PENALTY = 25;

    @Override
    public void apply(String id) {
        /*
        Object test = Global.getSettings().getSpec(ConditionGenDataSpec.class, condition.getId(), true);
        if (test instanceof ConditionGenDataSpec) {
            ConditionGenDataSpec spec = (ConditionGenDataSpec) test;
            float hazard = spec.getHazard();
            if (hazard != 0) {
                market.getHazard().modifyFlat(id, hazard, condition.getName());
            }
        }*/
        super.apply(id);
    }

    @Override
    public void unapply(String id) {
        //market.getHazard().unmodify(id);
        super.unapply(id);
    }
    
    @Override
    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
        super.createTooltipAfterDescription(tooltip, expanded);
        /*
        Object test = Global.getSettings().getSpec(ConditionGenDataSpec.class, condition.getId(), true);        
        if (test instanceof ConditionGenDataSpec) {
            ConditionGenDataSpec spec = (ConditionGenDataSpec) test;
            float hazard = spec.getHazard();
            if (hazard != 0) {
                String pct = "" + (int)(hazard * 100f) + "%";
                if (hazard > 0) pct = "+" + pct;
                tooltip.addPara(
                        "%s hazard rating.",
                        10f,
                        Misc.getHighlightColor(),
                        pct
                );
            }
        }
        */
    }
}
