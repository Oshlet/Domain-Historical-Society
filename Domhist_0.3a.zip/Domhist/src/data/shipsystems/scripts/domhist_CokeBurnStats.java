package data.shipsystems.scripts;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import com.fs.starfarer.api.util.Misc;

public class domhist_CokeBurnStats extends BaseShipSystemScript {

private float smokeCount = 3f;
private float fxDelay = 0.2f;
private boolean boosted = false;

	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
	  
	  ShipAPI ship0 = (ShipAPI)stats.getEntity();
	  CombatEngineAPI engine = Global.getCombatEngine();
	  float timer = engine.getElapsedInLastFrame() * effectLevel;
	  float timerFlat = engine.getElapsedInLastFrame();
	  
	   // first, we BOOST
	  if (!boosted && state == ShipSystemStatsScript.State.ACTIVE) {
		  Vector2f direction = new Vector2f();
		  if (ship0.getEngineController().isAccelerating()) {
			  direction.y += 0.8f;
		  } else if (ship0.getEngineController().isAcceleratingBackwards() || ship0.getEngineController().isDecelerating()) {
			  direction.y -= 0.6f; // 0.2 weaker when in reverse
		  }
		  if (ship0.getEngineController().isStrafingLeft()) {
			  direction.x -= 0.9f; // strafing is stronger
		  } else if (ship0.getEngineController().isStrafingRight()) {
			  direction.x += 0.9f; // strafing is stronger
		  }
		  if (direction.length() <= 0f) {
			  direction.y = 0.6f; // if no input, then you get a weak forwards dash, because lol
		  }
		  Misc.normalise(direction);
		  VectorUtils.rotate(direction, ship0.getFacing() - 90f, direction);
		  direction.scale(ship0.getMaxSpeedWithoutBoost() * 1.3f);
		  Vector2f.add(ship0.getVelocity(), direction, ship0.getVelocity());
		  boosted = true;
	  }
	  
	   // then we spawn smoke
	  while (smokeCount >= 0f) {
		  smokeCount -= 1f;
	      
		  for (WeaponSlotAPI weapon : ship0.getHullSpec().getAllWeaponSlotsCopy()) {
			  if (weapon.isSystemSlot()) {
              
				  Vector2f randomPos = MathUtils.getRandomPointInCircle(null, 10f);
				  Vector2f posZero = weapon.computePosition(ship0);
				  posZero.x += randomPos.x;
				  posZero.y += randomPos.y;
              
				  float randomSize1 = MathUtils.getRandomNumberInRange(25f, 35f);
				  
				  Vector2f smokeVel = new Vector2f();
				  smokeVel.x += ship0.getVelocity().x;
				  smokeVel.y += ship0.getVelocity().y;
				  
				  smokeVel.x *= MathUtils.getRandomNumberInRange(0.6f, 0.7f);
				  smokeVel.y *= MathUtils.getRandomNumberInRange(0.6f, 0.7f);
				  
				  engine.addSwirlyNebulaParticle(posZero,
						  smokeVel,
						  randomSize1, //size
						  2.0f, //end mult
						  0.5f, //ramp fraction
						  0.5f, //full bright fraction
						  0.3f, //0.9 //duration
						  new Color(115,105,100,55), // 75 alpha
						  true);
                
				  engine.addNebulaParticle(posZero,
						  smokeVel,
						  randomSize1 + 10f, //size
						  2.2f, //end mult
						  0.5f, //ramp fraction
						  0.75f, //full bright fraction
						  0.4f, //1.1 //duration
						  new Color(115,105,100,80), //105 alpha
						  true);
              
				  for (int i=0; i < 6; i++) {
					  
					  Vector2f randomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(21f, 81f));
					  
					  Vector2f sparkVel = new Vector2f();
					  sparkVel.x += ship0.getVelocity().x;
					  sparkVel.y += ship0.getVelocity().y;
					  
					  sparkVel.x *= MathUtils.getRandomNumberInRange(0.5f, 0.6f);
					  sparkVel.y *= MathUtils.getRandomNumberInRange(0.5f, 0.6f);
					  
					  randomVel.x += sparkVel.x;
					  randomVel.y += sparkVel.y;
					  
					  float randomSize2 = MathUtils.getRandomNumberInRange(4f, 11f);
                
					  engine.addSmoothParticle(weapon.computePosition(ship0),
							  randomVel,
							  randomSize2, //size
							  1.0f, //brightness
							  0.45f, //duration
							  new Color(255,120,80,255));
				  }
			  }
		  }
	  }
	  
	   // here we do a timer to re-trigger smoke spawning
	  if (fxDelay >= 0f) {
		  fxDelay -= timer;
	  } else {
		  fxDelay = 0.1f;
		  smokeCount += 1f;
	  }
	  
	   // then we modify ship stats
	  stats.getMaxSpeed().modifyFlat(id, 175f * effectLevel);
	  stats.getAcceleration().modifyPercent(id, 200f * effectLevel);
	  stats.getDeceleration().modifyPercent(id, 200f * effectLevel);
	  stats.getTurnAcceleration().modifyPercent(id, 120f * effectLevel);
	  stats.getMaxTurnRate().modifyPercent(id, 60f * effectLevel);
	  
	   // this is to slow the ship down towards normal max speed during the OUT state
	  if (state == ShipSystemStatsScript.State.OUT) {
		  if (ship0.getVelocity().lengthSquared() > (ship0.getMaxSpeed() * ship0.getMaxSpeed())) {
			  float decelMult = Math.max(0.5f, Math.min(2f, stats.getDeceleration().getModifiedValue() / stats.getDeceleration().getBaseValue()));
	          float adjFalloffPerSec = 0.25f * (float) Math.pow(decelMult, 0.5);
	          ship0.getVelocity().scale((float) Math.pow(adjFalloffPerSec, timerFlat));
	  		}
	  }
	  
	   // make special engines do the thing
	  if (stats.getEntity() instanceof ShipAPI && false) {
		  ShipAPI ship = (ShipAPI) stats.getEntity();
		  String key = ship.getId() + "_" + id;
		  Object test = Global.getCombatEngine().getCustomData().get(key);
		  if (state == State.IN) {
			  if (test == null && effectLevel > 0.2f) {
				  Global.getCombatEngine().getCustomData().put(key, new Object());
				  ship.getEngineController().getExtendLengthFraction().advance(1f);
				  for (ShipEngineAPI shipEngine : ship.getEngineController().getShipEngines()) {
					  if (shipEngine.isSystemActivated()) {
						  ship.getEngineController().setFlameLevel(shipEngine.getEngineSlot(), 1f);
					  }
				  }
			  }
		  } else {
			  Global.getCombatEngine().getCustomData().remove(key);
		  }
	  }
	}
	
	public void unapply(MutableShipStatsAPI stats, String id) {
		stats.getMaxSpeed().unmodify(id);
		stats.getMaxTurnRate().unmodify(id);
		stats.getTurnAcceleration().unmodify(id);
		stats.getAcceleration().unmodify(id);
		stats.getDeceleration().unmodify(id);
		smokeCount = 3f;
		fxDelay = 0.2f;
		boosted = false;
	}
	
	public StatusData getStatusData(int index, State state, float effectLevel) {
		if (index == 0) {
			return new StatusData("improved maneuverability", false);
		} else if (index == 1) {
			return new StatusData("+175 top speed", false);
		}
		return null;
	}
}
