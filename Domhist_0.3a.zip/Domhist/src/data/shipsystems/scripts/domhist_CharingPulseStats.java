package data.shipsystems.scripts;

import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import com.fs.starfarer.api.util.IntervalUtil;

public class domhist_CharingPulseStats extends BaseShipSystemScript {

	private CombatEngineAPI engine;
	
	private static final float PULSE_RANGE = 400f;
	public static final float SHIELD_IN_DAM_BONUS = 70f;
	public static final float SHIELD_DAM_BONUS = 30f;
	public static final float SHIELD_UPKEEP_BONUS = 50f;
	
	public static final float SHUNT_RESIST_LEVEL = 0.75f; // shunt gets general damage resist, but only during the IN state
	
	private int ARCS_FIRED = 0;
	
	private boolean FIRED = false;

	private IntervalUtil arcInterval = new IntervalUtil(0.03f, 0.05f); // timing on visual arcs, looks very rapid but remember it has effectLevel scaling!
	private IntervalUtil ventInterval = new IntervalUtil(0.05f, 0.05f); // timer for ""vent""
	private IntervalUtil ventFxInterval = new IntervalUtil(0.2f, 0.2f); // timer for ""vent"" FX
	
	
	// private static final Color PULSE_INNER_COLOR = new Color (255, 10, 10, 70);
    // private static final Color PULSE_RING_COLOR = new Color (255, 100, 100, 175);
	
	@Override
	public void apply(MutableShipStatsAPI stats, final String id, State state, float effectLevel) {
        if (engine != Global.getCombatEngine()) {
            engine = Global.getCombatEngine();
        }
        
        // initial variable setup
        ShipAPI ship = (ShipAPI)stats.getEntity();
        float range = getMaxRange(ship);
        float timer = engine.getElapsedInLastFrame();
        
        int n_i_grn = (int) (125 - (115 * effectLevel));
		int n_i_blu = (int) (125 - (115 * effectLevel));
		int n_i_alp = (int) (75 - (5 * effectLevel));
		
		int n_r_grn = (int) (255 - (155 * effectLevel));
		int n_r_blu = (int) (255 - (155 * effectLevel));
		int n_r_alp = (int) (255 - (80 * effectLevel));
		
		Color newInner = new Color(255, n_i_grn, n_i_blu, n_i_alp); 
		Color newRing = new Color(255, n_r_grn, n_r_blu, n_r_alp);
        
		
        if (ship.getShield() == null) {
			float radius = ship.getCollisionRadius();
			
			// radial visual arcs + jitter (only spawned before the pulse, because reasons)
    		if (!FIRED) {

    			stats.getHullDamageTakenMult().modifyMult(id, SHUNT_RESIST_LEVEL);
    			stats.getArmorDamageTakenMult().modifyMult(id, SHUNT_RESIST_LEVEL);
    			stats.getEmpDamageTakenMult().modifyMult(id, SHUNT_RESIST_LEVEL);
    			
    			float jitterRangeBonus_1 = 2f * (1f + effectLevel);
    			float jitterRangeBonus_2 = 6f * (1f + effectLevel);
    			
    			Color jitterCol = new Color(200, 25, 25, 65);
    			
    			ship.setJitter(this, jitterCol, effectLevel, 3, 0, 8f + jitterRangeBonus_1);
    			ship.setJitterUnder(this, jitterCol, effectLevel, 10, 0f, 12f + jitterRangeBonus_2);
    			
    			arcInterval.advance(timer * effectLevel);
    			
    			if (arcInterval.intervalElapsed()) {
    				for (int i=0; i < 3; i++) {
    					float angle1 = MathUtils.getRandomNumberInRange(-180f, 180f);
    					float randDist1 = radius * MathUtils.getRandomNumberInRange(0.25f, 0.85f);
    					Vector2f loc1 = MathUtils.getPointOnCircumference(ship.getLocation(), randDist1, angle1);
    					
    					float angle2 = angle1 += MathUtils.getRandomNumberInRange(45f, 90f);
    					float randDist2 = radius * MathUtils.getRandomNumberInRange(0.7f, 0.85f);
    					Vector2f loc2 = MathUtils.getPointOnCircumference(ship.getLocation(), randDist2, angle2);
    					
    					engine.spawnEmpArcVisual(loc1, ship, loc2, ship, 11f,newInner,newRing);
    				}
    			}
    		} else {
    			stats.getHullDamageTakenMult().unmodify(id);
    			stats.getArmorDamageTakenMult().unmodify(id);
    			stats.getEmpDamageTakenMult().unmodify(id);
    		}
    		
    		// Pulse
    		if (state == ShipSystemStatsScript.State.ACTIVE && !FIRED) {
    			FIRED = true;
    			
    			// pulse damage to ships
            	for (ShipAPI target_ship : engine.getShips()) {
        			// check if the ship is a valid target
            		if (target_ship.isHulk() || target_ship.getOwner() == ship.getOwner()) {
            			continue;
            		}
                
                	// check if the ship is in range, if yes, then do some damage!
            		float angle = VectorUtils.getAngle(ship.getLocation(), target_ship.getLocation());
            		if (MathUtils.getDistance(ship, target_ship) <= (range + (radius * 0.5f))) {
            			
            			int arcCount = 100 + (int) target_ship.getCollisionRadius();
            			// so we do more arcs to larger targets :)))))))
            			
            			// Shield Shunt makes EMP arcs +25% damage, and slightly more of them spawned against ships, to compensate for no shield damage resist
            			for (int i=0; i < arcCount; i+=45) {
            				engine.spawnEmpArc(ship,
                                    MathUtils.getPointOnCircumference(ship.getLocation(),radius * MathUtils.getRandomNumberInRange(0.4f, 0.8f),angle),
                                    ship,
                                    target_ship,
                                    DamageType.ENERGY,
                                    125f,
                                    200f,
                                    range + 100f,
                                    "tachyon_lance_emp_impact",
                                    13,
                                    newInner,
                                    newRing);
            				ARCS_FIRED++;
            			}
            		}
            	}
            	
    			// pulse damage to missiles
            	for (MissileAPI target_missile : engine.getMissiles()) {
        			// check if the missile is a valid target
            		if (target_missile.getOwner() == ship.getOwner()) {
            			continue;
            		}
            		
                	// check if the missile is in range, if yes, zap it with an emp arc :)))
            		float angle = VectorUtils.getAngle(ship.getLocation(), target_missile.getLocation());
            		if (MathUtils.getDistance(ship, target_missile) <= (range + (radius * 0.5f))) {
            			
                        engine.spawnEmpArc(ship,
                                MathUtils.getPointOnCircumference(ship.getLocation(),MathUtils.getRandomNumberInRange(radius * 0.4f, radius * 0.8f),angle),
                                ship,
                                target_missile,
                                DamageType.ENERGY,
                                125f,
                                200f,
                                range + 100f,
                                "tachyon_lance_emp_impact",
                                13f,
                                newInner,
                                newRing);
                        ARCS_FIRED++;
            		}
            	}
            	
            	
            	// spawn extra visual emp arcs, but not as many if stuff has already been arced to
            	int extraArcs = Math.max(30 - ARCS_FIRED, 10);
            	
            	for (int j=0; j < extraArcs; j++) {
            		
            		float fxAngle1 = MathUtils.getRandomNumberInRange(-180f, 180f);
    				float fxDist1 = radius * MathUtils.getRandomNumberInRange(0.4f, 0.8f);
    				Vector2f fxLoc1 = MathUtils.getPointOnCircumference(ship.getLocation(), fxDist1, fxAngle1);
    				
    				float fxAngle2 = fxAngle1 + MathUtils.getRandomNumberInRange(-8f, 8f);
    				float fxDist2 = radius + (range * MathUtils.getRandomNumberInRange(0.2f, 0.9f));
    				Vector2f fxLoc2 = MathUtils.getPointOnCircumference(ship.getLocation(), fxDist2, fxAngle2);
    				
            		engine.spawnEmpArcVisual(
            				fxLoc1,
            				ship,
            				fxLoc2,
            				ship,
            				13f,
            				newInner,
            				newRing);
            	}
            	
            	// spawn a spray of particles!
            	for (int k=0; k < 1800; k++) {
            		for (int k2=0; k2 < 6; k2++) {
                		Vector2f particleLoc = MathUtils.getPointOnCircumference(ship.getLocation(), radius * MathUtils.getRandomNumberInRange(0.01f, 0.25f), k);
                		
        				Vector2f tempPartVel = VectorUtils.getDirectionalVector(ship.getLocation(), particleLoc);
        				Vector2f particleVel = new Vector2f();
        				VectorUtils.resize(tempPartVel, MathUtils.getRandomNumberInRange((radius + range) * 0.1f, (radius + range) * 1.8f), particleVel);
        				
        				int colorMod = 75 + (k2 * 10); // B/G channels were 100
        				
                		engine.addSmoothParticle(particleLoc,
                				MathUtils.getRandomPointInCircle(particleVel, 12f), //vel
                				MathUtils.getRandomNumberInRange(4f, 11f), //size
                				1.0f, //brightness
                				MathUtils.getRandomNumberInRange(0.3f, 0.55f), //duration
                				new Color(255, colorMod, colorMod, 175));
            		}
            	}
            	
            	// spawn an explosion effect, because no shield
            	engine.spawnExplosion(ship.getLocation(), ship.getVelocity(), newInner, radius, 0.4f);
            	
            	// some SFX!
            	Global.getSoundPlayer().playSound("tachyon_lance_emp_impact", 0.7f, 1.2f, ship.getLocation(), ship.getVelocity());
            	Global.getSoundPlayer().playSound("system_emp_emitter_impact", 0.9f, 1.2f, ship.getLocation(), ship.getVelocity());
    		}	
        } else {
        	ShieldAPI shield = ship.getShield();
            float shieldAngle = shield.getFacing();
            
    		// shield stuff (color and (relatively) minor buffs
    		shield.setInnerColor(newInner);
    		shield.setRingColor(newRing);

            stats.getShieldUpkeepMult().modifyMult(id, 1f - ((SHIELD_UPKEEP_BONUS / 100f )));
    		
            // we have "minor" (30%) damage resist normally, but during the "in/active" states it's cranked up to 70%, because you are forced to keep the shield up.
            if (state == ShipSystemStatsScript.State.IN || state == ShipSystemStatsScript.State.ACTIVE) {
    			stats.getShieldDamageTakenMult().modifyMult(id, 1f - (SHIELD_IN_DAM_BONUS / 100f));
            } else {
    			stats.getShieldDamageTakenMult().modifyMult(id, 1f - ((SHIELD_DAM_BONUS / 100f) * effectLevel));
            }
            
    		float radius = shield.getRadius();
    		float arc = shield.getActiveArc();
    		
    		// shield visual arcs (only spawn them before the pulse, because reasons)
    		if (!FIRED) {
    			stats.getShieldUnfoldRateMult().modifyMult(id, 4f); // massive initial shield unfold bonus
    			
    			// force shield on
    			shield.toggleOn();
    	        ship.blockCommandForOneFrame(ShipCommand.TOGGLE_SHIELD_OR_PHASE_CLOAK);
    			
    			arcInterval.advance(timer * effectLevel);
    			
    			if (arcInterval.intervalElapsed()) {
    				for (int i=0; i < 3; i++) {
    					float angle1 = (float) ((Math.random() * arc - (arc * 0.5f)) + shieldAngle);
    					float randDist1 = radius * MathUtils.getRandomNumberInRange(0.96f, 1.04f);
    					Vector2f loc1 = MathUtils.getPointOnCircumference(ship.getLocation(), randDist1, angle1);
    					
    					float angle2 = (float) ((Math.random() * arc - (arc * 0.5f)) + shieldAngle);
    					float randDist2 = radius * MathUtils.getRandomNumberInRange(0.96f, 1.04f);
    					Vector2f loc2 = MathUtils.getPointOnCircumference(ship.getLocation(), randDist2, angle2);
    					
    					engine.spawnEmpArcVisual(loc1, ship, loc2, ship, 11f,newInner,newRing);
    				}
    			}
    		} else {
    			stats.getShieldUnfoldRateMult().modifyMult(id, 2f);
    		}
    		
    		// Pulse
    		if (state == ShipSystemStatsScript.State.ACTIVE && !FIRED) {
    			FIRED = true;
    			
    			// pulse damage to ships
            	for (ShipAPI target_ship : engine.getShips()) {
        			// check if the ship is a valid target
            		if (target_ship.isHulk() || target_ship.getOwner() == ship.getOwner()) {
            			continue;
            		}
                
                	// check if the ship is in the shield arc and in range, if yes to both, then do some damage!
            		float angle = VectorUtils.getAngle(ship.getLocation(), target_ship.getLocation());
            		if ((Math.abs(MathUtils.getShortestRotation(angle, shieldAngle)) <= (arc/2)) && (MathUtils.getDistance(ship, target_ship) <= (range+radius))) {
            			
            			int arcCount = 100 + (int) target_ship.getCollisionRadius();
            			// so we do more arcs to larger targets :)))))))
            			
            			for (int i=0; i < arcCount; i+=50) {
            				engine.spawnEmpArc(ship,
                                    MathUtils.getPointOnCircumference(ship.getLocation(),radius,angle),
                                    ship,
                                    target_ship,
                                    DamageType.ENERGY,
                                    100f,
                                    200f,
                                    range + 100f,
                                    "tachyon_lance_emp_impact",
                                    13,
                                    newInner,
                                    newRing);
            				ARCS_FIRED++;
            			}
            			
            			// the target eats 100 flux, because :)))
        				target_ship.getFluxTracker().increaseFlux(100f, true);
            		}
            	}
            	
    			// pulse damage to missiles
            	for (MissileAPI target_missile : engine.getMissiles()) {
        			// check if the missile is a valid target
            		if (target_missile.getOwner() == ship.getOwner()) {
            			continue;
            		}
            		
                	// check if the missile is in the shield arc and in range, if yes to both, zap it with an emp arc :)))
            		float angle = VectorUtils.getAngle(ship.getLocation(), target_missile.getLocation());
            		if ((Math.abs(MathUtils.getShortestRotation(angle, shieldAngle)) <= (arc/2)) && (MathUtils.getDistance(ship, target_missile) <= (range+radius))) {
            			
                        engine.spawnEmpArc(ship,
                                MathUtils.getPointOnCircumference(ship.getLocation(),radius,angle),
                                ship,
                                target_missile,
                                DamageType.ENERGY,
                                100f,
                                200f,
                                range + 100f,
                                "tachyon_lance_emp_impact",
                                13f,
                                newInner,
                                newRing);
                        ARCS_FIRED++;
            		}
            	}
            	
            	
            	// spawn extra visual emp arcs, but not as many if stuff has already been arced to, with EMP arc count scaling with shield arc size.
            	
            	int scaledExtryArcs = Math.max((int) (arc / 10), 12);
            	int smallerExtryArcs = Math.max((int) (scaledExtryArcs / 3), 4);
            	
            	int extraArcs = Math.max(scaledExtryArcs - ARCS_FIRED, smallerExtryArcs);
            	
            	for (int j=0; j < extraArcs; j++) {
            		
            		float fxAngle1 = (float) ((Math.random() * arc - (arc * 0.5f)) + shieldAngle);
    				float fxDist1 = radius * MathUtils.getRandomNumberInRange(0.96f, 1.04f);
    				Vector2f fxLoc1 = MathUtils.getPointOnCircumference(ship.getLocation(), fxDist1, fxAngle1);
    				
    				float fxAngle2 = fxAngle1 + MathUtils.getRandomNumberInRange(-8f, 8f);
    				float fxDist2 = radius + (range * MathUtils.getRandomNumberInRange(0.2f, 0.9f));
    				Vector2f fxLoc2 = MathUtils.getPointOnCircumference(ship.getLocation(), fxDist2, fxAngle2);
    				
            		engine.spawnEmpArcVisual(
            				fxLoc1,
            				ship,
            				fxLoc2,
            				ship,
            				13f,
            				newInner,
            				newRing);
            	}
            	
            	
            	// spawn a spray of particles!
            	for (int k=0; k < arc; k++) {
            		for (int k2=0; k2 < 4; k2++) {
                		float particleAngle = (float) ((k - 1 - (arc * 0.5f)) + shieldAngle);
        				Vector2f particleLoc = MathUtils.getPointOnCircumference(ship.getLocation(), radius, particleAngle);
                		
        				Vector2f tempPartVel = VectorUtils.getDirectionalVector(ship.getLocation(), particleLoc);
        				Vector2f particleVel = new Vector2f();
        				VectorUtils.resize(tempPartVel, MathUtils.getRandomNumberInRange(range * 0.1f, range * 1.8f), particleVel);
        				
        				int colorMod = 75 + (k2 * 15); // B/G channels were 100
        				
                		engine.addSmoothParticle(particleLoc,
                				MathUtils.getRandomPointInCircle(particleVel, 12f), //vel
                				MathUtils.getRandomNumberInRange(4f, 11f), //size
                				1.0f, //brightness
                				MathUtils.getRandomNumberInRange(0.3f, 0.55f), //duration
                				new Color(255, colorMod, colorMod, 175));
            		}
            	}
            	
            	// spawn a spread of fat nebulas
            	/*for (int l=0; l < arc; l+=10) {
            		
            		float nebulaAngle1 = (float) ((l - 10 - (arc * 0.5f)) + shieldAngle);
    				Vector2f nebulaLoc1 = MathUtils.getPointOnCircumference(ship.getLocation(), radius, nebulaAngle1);
            		
    				Vector2f tempNebulaVel1 = VectorUtils.getDirectionalVector(ship.getLocation(), nebulaLoc1);
    				Vector2f nebulaVel1 = new Vector2f();
    				VectorUtils.resize(tempNebulaVel1, range, nebulaVel1);
            		
            		engine.addSwirlyNebulaParticle(nebulaLoc1,
            				nebulaVel1,
    						10f, //size
    						range / 20f, //end mult
    						0.6f, //ramp fraction
    						0.4f, //full bright fraction
    						0.55f, //duration
    						new Color(200,30,30,25),
    						true);
            	}*/

            	// some SFX!
            	Global.getSoundPlayer().playSound("tachyon_lance_emp_impact", 0.7f, 1.2f, ship.getLocation(), ship.getVelocity());
            	Global.getSoundPlayer().playSound("system_emp_emitter_impact", 0.9f, 1.2f, ship.getLocation(), ship.getVelocity());
    		}	
        }
        
        
		// Flux Venting and VFX
		if (state == ShipSystemStatsScript.State.OUT) {
			
			ventInterval.advance(timer);
			ventFxInterval.advance(timer);
			
			if (ventInterval.intervalElapsed()) {
				// done like this because the setflux stuff only applies to hard/soft flux selectively
				// if we have less than 50 soft flux, then lower our hardflux level as well as our softflux level
				if (ship.getFluxTracker().getCurrFlux() - ship.getFluxTracker().getHardFlux() < 50f) {
					ship.getFluxTracker().setHardFlux(Math.max(0f, ship.getFluxTracker().getHardFlux() - 50f)); // 50*20 = venting at 1000 flux/sec
					//engine.addFloatingText(ship.getLocation(), "VENTING H", 25f, Color.red, ship, 1f, 1f);
				}// else {
					//engine.addFloatingText(ship.getLocation(), "VENTING S", 25f, Color.yellow, ship, 1f, 1f);
				//}
				ship.getFluxTracker().setCurrFlux(Math.max(0f, ship.getFluxTracker().getCurrFlux() - 50f));
			}
			
			if (ventFxInterval.intervalElapsed()) {
				for (WeaponSlotAPI weapon : ship.getHullSpec().getAllWeaponSlotsCopy()) {
					if (weapon.isSystemSlot()) {
						
						Vector2f randomPos = MathUtils.getRandomPointInCircle(weapon.computePosition(ship), 5f);
						
						engine.addSwirlyNebulaParticle(randomPos,
								ship.getVelocity(),
								MathUtils.getRandomNumberInRange(15f, 25f), //size
								  1.9f, //end mult
								  0.5f, //ramp fraction
								  0.5f, //full bright fraction
								  0.3f, //duration
								  new Color(125,115,110,70), // 115,105,100,50
								  true);
						
						engine.addNebulaSmokeParticle(randomPos,
								ship.getVelocity(),
								MathUtils.getRandomNumberInRange(20f, 30f), //size
								1.8f, //end mult
								0.5f, //ramp fraction
								0.6f, //full bright fraction
								0.4f, //duration
								new Color(115,110,125,80)); // 105,100,115,60
						
						engine.addNebulaParticle(randomPos,
								ship.getVelocity(),
								MathUtils.getRandomNumberInRange(25f, 35f), //size
								1.7f, //end mult
								0.5f, //ramp fraction
								0.75f, //full bright fraction
								0.5f, //duration
								new Color(115,110,125,105), // 105,100,115,85
								true);
						
						 for (int i=0; i < 4; i++) {
							  Vector2f randomPos2 = MathUtils.getRandomPointInCircle(weapon.computePosition(ship), 4f);
							  Vector2f sparkVel = MathUtils.getRandomPointOnCircumference(ship.getVelocity(), MathUtils.getRandomNumberInRange(20f, 80f));
							  
							  engine.addSmoothParticle(randomPos2,
									  sparkVel,
									  MathUtils.getRandomNumberInRange(4f, 10f), //size
									  1.0f, //brightness
									  0.4f, //duration
									  new Color(255,120,80,225)); //125,35,155,60
						 }
					}
				}
			}
		}
	}
	
	public void unapply(MutableShipStatsAPI stats, String id) {
		
    	FIRED = false;
    	ARCS_FIRED = 0;
    	
        stats.getShieldDamageTakenMult().unmodify(id);
        stats.getShieldUpkeepMult().unmodify(id);
        stats.getShieldUnfoldRateMult().unmodify(id);
        
        ShipAPI ship = (ShipAPI) stats.getEntity();
        if (ship == null) return;
        
        ShieldAPI shield = ship.getShield();
        if (shield == null) return;
        
        shield.setRingColor(ship.getHullSpec().getShieldSpec().getRingColor());
        shield.setInnerColor(ship.getHullSpec().getShieldSpec().getInnerColor());
        
		stats.getHullDamageTakenMult().unmodify(id);
		stats.getArmorDamageTakenMult().unmodify(id);
		stats.getEmpDamageTakenMult().unmodify(id);
        
	}

	public static float getMaxRange(ShipAPI ship) {
		return ship.getMutableStats().getSystemRangeBonus().computeEffective(PULSE_RANGE);
		// this method is so sysex gives you a longer range pulse!
	}
	
    public float getInOverride(ShipAPI ship) {
        if (ship.getShield() == null) {
            return 0.6f;
        } else {
            return 0.4f;
        }
        // we give the system a slightly longer chargeup if you are shunted.... because i say so :)))
    }
	
	public StatusData getStatusData(int index, State state, float effectLevel) {
		if (index == 0) {
			return new StatusData("Pulse Generator Active", false);
		}
		return null;
	}
}
