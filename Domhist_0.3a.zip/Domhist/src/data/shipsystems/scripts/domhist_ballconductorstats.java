package data.shipsystems.scripts;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;

public class domhist_ballconductorstats extends BaseShipSystemScript {

	public static final float RANGE_BONUS_P = 30f;
	public static final float RANGE_BONUS_F = 200f;
	public static final float SPEED_MALUS = 40f;
	public static final float TURN_BONUS = 60f;
	public static final float FLUX_BONUS = 0.1f;
	
	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		
		if (state == ShipSystemStatsScript.State.OUT) {
			stats.getMaxSpeed().unmodify(id);
			stats.getMaxTurnRate().unmodify(id);
		} else {
			
			float trueRange_p = stats.getSystemRangeBonus().computeEffective(RANGE_BONUS_P);
			float trueRange_f = stats.getSystemRangeBonus().computeEffective(RANGE_BONUS_F);
			
			stats.getMaxSpeed().modifyMult(id, 1f - (SPEED_MALUS * 0.01f * effectLevel));
			stats.getAcceleration().modifyMult(id, 1f - (SPEED_MALUS * 0.005f * effectLevel));
			stats.getDeceleration().modifyMult(id, 1f - (SPEED_MALUS * 0.005f * effectLevel));
			stats.getTurnAcceleration().modifyMult(id, 1f + (TURN_BONUS * 0.01f * effectLevel));
			stats.getMaxTurnRate().modifyMult(id, 1f + (TURN_BONUS * 0.01f * effectLevel));
			
			stats.getBallisticWeaponRangeBonus().modifyPercent(id, trueRange_p * effectLevel);
			stats.getEnergyWeaponRangeBonus().modifyPercent(id, trueRange_p * effectLevel);
			stats.getBallisticWeaponRangeBonus().modifyFlat(id, trueRange_f * effectLevel);
			stats.getEnergyWeaponRangeBonus().modifyFlat(id, trueRange_f * effectLevel);
		
			stats.getEnergyWeaponFluxCostMod().modifyMult(id, 1f - (FLUX_BONUS * effectLevel));
			stats.getBallisticWeaponFluxCostMod().modifyMult(id, 1f - (FLUX_BONUS * effectLevel));
			stats.getMissileWeaponFluxCostMod().modifyMult(id, 1f - (FLUX_BONUS * effectLevel));
		}
	}
	
	public void unapply(MutableShipStatsAPI stats, String id) {
	  stats.getMaxSpeed().unmodify(id);
		stats.getMaxTurnRate().unmodify(id);
		stats.getTurnAcceleration().unmodify(id);
		stats.getAcceleration().unmodify(id);
		stats.getDeceleration().unmodify(id);
		
		stats.getBallisticWeaponRangeBonus().unmodify(id);
		stats.getEnergyWeaponRangeBonus().unmodify(id);
		
		stats.getEnergyWeaponFluxCostMod().unmodify(id);
		stats.getBallisticWeaponFluxCostMod().unmodify(id);
		stats.getMissileWeaponFluxCostMod().unmodify(id);
	}
	
	public StatusData getStatusData(int index, State state, float effectLevel) {
	  
		if (index == 0) {
		  return new StatusData("Increased weapon range", false);
		} else if (index == 1) {
			return new StatusData("Improved turning", false);
		} else if (index == 2) {
		  return new StatusData("Reduced top speed", true);
		}
		return null;
	}
}

