// based on tims "eis_myironstandseternal"

package data.shipsystems.scripts.ai;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class domhist_CharingPulseAI implements ShipSystemAIScript {
	
    private ShipAPI ship;
    private CombatEngineAPI engine;
    private ShipSystemAPI system;
    
    private final IntervalUtil timer = new IntervalUtil(0.4f, 0.4f); // frequent ticks, because short system range
    private static final float RANGE = 400f; // the base range of the system
    
    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.engine = engine;
        this.system = system;
    }
    
    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
    	
    	// standard sanity checks
    	if (engine == null) {
    		return;
    	}
    	if (engine.isPaused()) {
    		return;
    	}
    	
        timer.advance(amount);
        
        if (timer.intervalElapsed()) {
        	if (!ship.getFluxTracker().isOverloadedOrVenting() || !system.isActive() || !system.isCoolingDown()) {
        		float missileThreatLevel = 0f;
        		int missileThreatAmount = 0;
        		
        		float rangeCalc = (ship.getMutableStats().getSystemRangeBonus().computeEffective(RANGE));
        		
        		List<MissileAPI> allMissiles = CombatUtils.getMissilesWithinRange(ship.getLocation(), ship.getCollisionRadius() + rangeCalc + 50f);
        			// scan at +50 range, because the system has a "spool" time
        		for (MissileAPI missile : allMissiles) {
        			float angle = Math.abs(VectorUtils.getAngle(ship.getLocation(), missile.getLocation()));
        			
        			float dir = ship.getFacing();
        			float scanAngle = 1f;
        			
        			// set scan angle/arc based on whether we have a shield or not
        			if (ship.getShield() == null) {
        				scanAngle = 360f;
        			} else {
        				scanAngle = ship.getShield().getArc() / 2;
                		// we check against max arc, because of the rapid raise feature of the system
        				
                		if (ship.getShield().isOn()) {
                			dir = ship.getShield().getFacing(); // if your shield is on, it will scan in the facing of the shield
            			}
        			}
        			
        			if ((missile.getOwner() != ship.getOwner()) && (MathUtils.getShortestRotation(angle, dir) <= scanAngle)) {
        				float scale = 1f;
        				switch (missile.getDamageType()) {
        				case FRAGMENTATION:
        					scale = 0.25f; // frag is frag, and we have pretty good armour :)
        					break;
        				case KINETIC:
        					scale = 1.6f; // pls say no to shield damage :(((
        					break;
        				case HIGH_EXPLOSIVE:
        					scale = 0.9f; // kinda scary, but we can shield tank it!
        					break;
        				default:
        				case ENERGY:
        					scale = 1.2f; // energy missiles are often rude, do not underestimate! 
        					break;
        				}
        				missileThreatLevel += missile.getDamageAmount() * scale;
        				if (missile.getDamageAmount() >= 1000f || missile.getEmpAmount() >= 500f) {
        					missileThreatAmount += 2;
        				} else {
        					missileThreatAmount += 1;
        				}
        			}
        		}
        		
        		/*
        		use system if missile threat is bigger than:
        		
        		0.5 * health * (1 - flux level)
        		*/
        		
                if (missileThreatLevel >= 0.5 * ship.getHitpoints() * (1 - ship.getFluxLevel()) || missileThreatAmount >= 4 || ship.getFluxLevel() > 0.85f) {
                    ship.useSystem();
                }
        	}
        }
    }
  }