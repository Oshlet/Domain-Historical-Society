// based on the parade burn script, so once again credit for actual scripting to Nia Tahl + Vayra

package data.shipsystems.scripts.ai;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.ArrayList;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class domhist_BallConductorAI implements ShipSystemAIScript {

    private ShipAPI ship;
    private ShipwideAIFlags flags;
    private CombatEngineAPI engine;

    // only check approximately every half-second (for optimization, semi random timing to because synchronisation is not a goal here)
    private final IntervalUtil timer = new IntervalUtil(0.4f, 0.55f);
    
    // setup
    private static final float CORE_DEGREES = 10f;
    private static final float SCAN_RANGE = 1000f; // size of area to check for threats.
    private static final float WOUNDED_DAMAGE_THRESHOLD = 300f; // how much hull damage does a proj have to do before we are scared of it
    
    // list of flags to check for whether it is generally GOOD or BAD to use the system.
    private static final ArrayList<AIFlags> GOOD = new ArrayList<AIFlags>();
    private static final ArrayList<AIFlags> BAD = new ArrayList<AIFlags>();

    static {
        GOOD.add(AIFlags.TURN_QUICKLY);
        BAD.add(AIFlags.PURSUING);
        BAD.add(AIFlags.HARASS_MOVE_IN);
        BAD.add(AIFlags.RUN_QUICKLY);
        BAD.add(AIFlags.BACK_OFF);
        BAD.add(AIFlags.BACK_OFF_MIN_RANGE);
        BAD.add(AIFlags.KEEP_SHIELDS_ON);
    }
        
    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.flags = flags;
        this.engine = engine;
    }
    
    // method to check if we're facing within X degrees of target
    private boolean rightDirection(ShipAPI ship, Vector2f targetLocation) {
        Vector2f curr = ship.getLocation();
        float angleToTarget = VectorUtils.getAngle(curr, targetLocation);
        return (Math.abs(MathUtils.getShortestRotation(angleToTarget, ship.getFacing())) <= CORE_DEGREES);
    }


    private boolean nothingCanStopMe(ShipAPI ship) {

        // setup
        Vector2f curr = ship.getLocation();
        boolean hasTakenHullDamage = ship.getHullLevel() < 0.99f;
        boolean safe = true;

        // scan everything within x range
        List<CombatEntityAPI> consider = CombatUtils.getEntitiesWithinRange(curr, SCAN_RANGE);
        for (CombatEntityAPI test : consider) {

            // check for projectiles within "threat radius"
            if (test instanceof DamagingProjectileAPI) {
                DamagingProjectileAPI proj = (DamagingProjectileAPI) test;
                float armor = ship.getArmorGrid().getArmorRating();
                float armorDamage = proj.getDamageAmount();
                float hullDamage = proj.getDamageAmount();
                switch (proj.getDamageType()) {
                    case KINETIC:
                        armorDamage *= 0.5f;
                        break;
                    case FRAGMENTATION:
                        armorDamage *= 0.25f;
                        hullDamage *= 0.25f;
                        break;
                    case HIGH_EXPLOSIVE:
                        armorDamage *= 2f;
                        break;
                    case ENERGY:
                    	break;
                    case OTHER:
                    	break;
                    default:
                    	break;
                }

                if (armorDamage >= armor) {
                    safe = false;
                }
                if (hasTakenHullDamage && hullDamage >= WOUNDED_DAMAGE_THRESHOLD) {
                    safe = false;
                }   
            }
        }
        return safe;
    }
    
	public static float getMaxRange(ShipAPI ship) {
		
		// calculate the boosted range of the longest range gun on the ship
		
		float range = 0f;
		
		for (WeaponAPI w : ship.getAllWeapons()) {
			if (w.getType() == WeaponType.BALLISTIC || w.getType() == WeaponType.ENERGY) {
				float curr = w.getRange();
				if (curr > range) range = curr;
			}
		}
		
        float percMod = ship.getMutableStats().getSystemRangeBonus().computeEffective(1.3f);
        float flatMod = ship.getMutableStats().getSystemRangeBonus().computeEffective(200f);
        
		return ((range * percMod) + flatMod);
	}
	
	public static float getBaseRange(ShipAPI ship) {
		
		// calculate the base range of the longest range gun on the ship
		
		float range = 0f;
		
		for (WeaponAPI w : ship.getAllWeapons()) {
			if (w.getType() == WeaponType.BALLISTIC || w.getType() == WeaponType.ENERGY) {
				float curr = w.getRange();
				if (curr > range) range = curr;
			}
		}
		return range;
	}
    
    
    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {

        // don't check if paused
        if (engine.isPaused()) {
            return;
        }

        // don't check if timer not up
        timer.advance(amount);
        if (!timer.intervalElapsed()) {
            return;
        }

        // don't use if can't use
        if (!AIUtils.canUseSystemThisFrame(ship)) {
            return;
        }
        
        // don't use if unsafe
        if (!nothingCanStopMe(ship)) {
            return;
        }

        // setup variables
        boolean useMe = false;
        Vector2f targetLocation = null;
        
        
        
        // if we have a hostile target, set our target loc to it
        if (target != null && target.getOwner() != ship.getOwner()) {
            targetLocation = target.getLocation();
        }
        // if our hostile target is within boosted range, activate (we're ignoring facing here because the system boosts turning as well)
        if (targetLocation == null) {
            return;
        } else if (MathUtils.isWithinRange(ship, target, getMaxRange(ship))) {
            useMe = true;
        }
        
        
        // check AIFLags to determine if we might want to use the system.
        for (AIFlags f : GOOD) {
            if (flags.hasFlag(f) && !rightDirection(ship, targetLocation)) {
                useMe = true;
            }
        }
        for (AIFlags f : BAD) {
            if (flags.hasFlag(f)) {
                useMe = false;
            }
        }

        // Do not use if target is within standard gun range of at least one gun and we are more or less facing it.
        if (target != null) {
          if (MathUtils.isWithinRange(ship, target, getBaseRange(ship)) && rightDirection(ship, targetLocation)) {
            useMe = false;
          }
        }

        if (useMe) {
            ship.useSystem();
        }

    }
  }