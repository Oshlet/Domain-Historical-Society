// based on the parade burn script, so once again credit for actual scripting to Nia Tahl + Vayra

package data.shipsystems.scripts.ai;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.ArrayList;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class domhist_ChainHomeAI implements ShipSystemAIScript {

    private ShipAPI ship;
    private ShipwideAIFlags flags;
    private CombatEngineAPI engine;

    // check once every half-second for optimisation and consistency
    private final IntervalUtil timer = new IntervalUtil(0.5f, 0.5f);
    
    // setup
    private static final float DEGREES = 25f; // system arc size
    private static final float RANGE = 2000f; // the range of the system, and as such how far to scan for targets
    private static final float ALLY_RANGE = 1200f; // the area around the ship to check for allies
    private static final float SCAN_RANGE = 700f; // size of area to check for threats.
    private static final float WOUNDED_DAMAGE_THRESHOLD = 300f; // how much hull damage does a projectile have to do before we are scared of it

    private float VALUE_ENEMY = 0f; // variables that are used later
    private float VALUE_ALLY = 0f;
    
    // list of flags to check for whether it is generally GOOD or BAD to use the system.
    private static final ArrayList<AIFlags> BAD = new ArrayList<AIFlags>();

    static {
        BAD.add(AIFlags.KEEP_SHIELDS_ON);
    }
        
    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.flags = flags;
        this.engine = engine;
    }
    

    // method to check if there are threatening projectiles within x range.
    private boolean nothingCanStopMe(ShipAPI ship) {

        // setup
        Vector2f curr = ship.getLocation();
        boolean hasTakenHullDamage = ship.getHullLevel() < 0.99f;
        boolean safe = true;

        // scan everything within x range
        List<CombatEntityAPI> consider = CombatUtils.getEntitiesWithinRange(curr, SCAN_RANGE);
        for (CombatEntityAPI test : consider) {
        	
        	float armorDamage = 0f;
            float hullDamage = 0f;
            float armor = ship.getArmorGrid().getArmorRating();
            // check for projectiles within "threat radius"
            if (test instanceof DamagingProjectileAPI) {
                DamagingProjectileAPI proj = (DamagingProjectileAPI) test;
                armorDamage = proj.getDamageAmount();
                hullDamage = proj.getDamageAmount();
                switch (proj.getDamageType()) {
                case KINETIC:
                	armorDamage *= 0.5f;
                	break;
                case FRAGMENTATION:
                	armorDamage *= 0.25f;
                	hullDamage *= 0.25f;
                	break;
                case HIGH_EXPLOSIVE:
                	armorDamage *= 2f;
                	break;
                case ENERGY:
                	break;
                case OTHER:
                	break;
                default:
                	break;
                }
            } else if (test instanceof MissileAPI) {
            	MissileAPI proj = (MissileAPI) test;
                armorDamage = proj.getDamageAmount();
                hullDamage = proj.getDamageAmount();
                switch (proj.getDamageType()) {
                case KINETIC:
                	armorDamage *= 0.5f;
                	break;
                case FRAGMENTATION:
                	armorDamage *= 0.25f;
                	hullDamage *= 0.25f;
                	break;
                case HIGH_EXPLOSIVE:
                	armorDamage *= 2f;
                	break;
                case ENERGY:
                	break;
                case OTHER:
                	break;
                default:
                	break;
                }
            }
            if (armorDamage >= armor) {
            	safe = false;
            }
            if (hasTakenHullDamage && hullDamage >= WOUNDED_DAMAGE_THRESHOLD) {
            	safe = false;
            }
        }
        return safe;
    }
    
    // method to grade the "value" of hostile ships within the systems cone
    private int enemyCount(ShipAPI ship) {

        // setup
        int counter = 0;
    	
    	for (ShipAPI target_ship : engine.getShips()) {
			// check if the ship is a valid target
    		if (target_ship.isHulk() || target_ship.isFighter() || target_ship.getOwner() == 100) {
    			continue;
    		}
    		float angle = VectorUtils.getAngle(ship.getLocation(), target_ship.getLocation());
    		if ((Math.abs(MathUtils.getShortestRotation(angle, ship.getFacing())) <= DEGREES) && (MathUtils.getDistance(ship, target_ship) <= (ship.getMutableStats().getSystemRangeBonus().computeEffective(RANGE)))) {
                if (target_ship.getOwner() != ship.getOwner()) {
            		HullSize size = ship.getHullSize();
            		HullSize otherSize = target_ship.getHullSize();
                	if (otherSize.compareTo(size) >= 1) {
                		counter += 3;
                	} else if (otherSize.compareTo(size) == 0) {
                		counter += 2;
                	} else {
                		counter += 1;
                	}
                }
    		}
    	}
        return counter;
    }
    
    // method to grade the "value" of allied ships within the systems cone
    private int allyCount(ShipAPI ship) {

        // setup
        int counter = 0;
        
    	for (ShipAPI target_ship : engine.getShips()) {
			// check if the ship is a valid target
    		if (target_ship.isHulk() || target_ship.isFighter() || target_ship.getOwner() == 100) {
    			continue;
    		}
    		if (MathUtils.getDistance(ship, target_ship) <= (ship.getMutableStats().getSystemRangeBonus().computeEffective(ALLY_RANGE))) {
                if (target_ship.getOwner() == ship.getOwner()) {
                	HullSize size = ship.getHullSize();
            		HullSize otherSize = target_ship.getHullSize();
                	if (otherSize.compareTo(size) >= 1) {
                		counter += 3;
                	} else if (otherSize.compareTo(size) == 0) {
                		counter += 2;
                	} else {
                		counter += 1;
                	}
                }
    		}
    	}
    	counter -= 2; // to counteract the fact that this will scan the ship using the system as well
        return counter;
    }
    
    
    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {

    	// don't check if paused / can't use the system / timer not up
        timer.advance(amount);
    	if (engine.isPaused() || !timer.intervalElapsed()) {
    		//  !AIUtils.canUseSystemThisFrame(ship) ||
            return;
        }
        
        // setup
        boolean keepShield = false;
        VALUE_ALLY = allyCount(ship);
        VALUE_ENEMY = enemyCount(ship);
        
        // debug info thinger
    	//if (ship == Global.getCombatEngine().getPlayerShip()) {
		//	Global.getCombatEngine().maintainStatusForPlayerShip("DHCHAINTEST", "", "CHAIN VALUE DEBUG", "E: " + VALUE_ENEMY + " / A: " + VALUE_ALLY, false);
		//}
        
         // check AIFLags to determine if we might want to keep shields up
        for (AIFlags f : BAD) {
            if (flags.hasFlag(f)) {
                keepShield = true;
            }
        }
        
        // perform an override if it's a bad idea to have the system active.
        if (!nothingCanStopMe(ship) || keepShield == true) {
        	if (ship.getSystem().isActive()) {
        		ship.useSystem();
        		return;
        	} else {
        		return;
        	}
        }
        
         // lets just simplifiy it, if there are any enemies and at leasst *some* allies nearby, use the system
        if (VALUE_ENEMY >= 1f && VALUE_ALLY >= 2f && !ship.getSystem().isActive()) {
    		ship.useSystem();
        }
        
        
         // disable the system if there are very few allies nearby
        if (ship.getSystem().isActive() && VALUE_ALLY < 2f) {
        	ship.useSystem();
        }
        
        
        /*
        // if we have some enemies in the arc, increment GOOD, and reduce DECAY
        if (enemyCount(ship) >=2) {
        	VALUE_GOOD += enemyCount(ship);
        	VALUE_DECAY = Math.max(0f, VALUE_DECAY -= Math.max(0f, (enemyCount(ship) - allyCount(ship))));
        }
        
        // if there are allies nearby, and GOOD is at least as high as the ally count, then activate the system and reduce clear DECAY
        // if the system is already active, then instead slowly reduce DECAY based on nearby ally count
        if (allyCount(ship) >= 2 && (VALUE_GOOD >= allyCount(ship))) {
        	if (!ship.getSystem().isActive()){
        		ship.useSystem();
        		VALUE_DECAY = 0f;
        		return;
        	} else {
        		VALUE_DECAY = Math.max(0f, VALUE_DECAY -= Math.max(0f, (enemyCount(ship) - allyCount(ship))));
        	}
        }
        
         // instant check for "is system active and is number of enemies kinda low"
        if (ship.getSystem().isActive() && VALUE_DECAY >= 20) {
        	ship.useSystem();
        	VALUE_GOOD = 0f;
    		return;
        }
        */
    }
  }