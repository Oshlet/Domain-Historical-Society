package data.shipsystems.scripts;

import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.impl.combat.MineStrikeStatsAIInfoProvider;
import com.fs.starfarer.api.util.Misc;

public class domhist_PhaseChargeStrikeStats extends BaseShipSystemScript implements MineStrikeStatsAIInfoProvider {

	// modified vanilla mine strike script	
	protected static float STRIKE_RANGE = 1000f;
	public static final float MINE_RADIUS = 200f; // the radius within which to drop the charges
	public static final int CHARGE_COUNT = 4;		  // how many charges to drop at once
	
	public static final float MIN_SPAWN_DIST = 70f;
	public static final float MIN_SPAWN_DIST_FRIGATE = 100f;
	
	public static final Color JITTER_COLOR = new Color(255,155,225,75);
	public static final Color JITTER_UNDER_COLOR = new Color(255,155,205,155);
	
	public static float getRange(ShipAPI ship) {
		if (ship == null) return STRIKE_RANGE;
		return ship.getMutableStats().getSystemRangeBonus().computeEffective(STRIKE_RANGE);
	}
	
	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		ShipAPI ship = null;
		if (stats.getEntity() instanceof ShipAPI) {
			ship = (ShipAPI) stats.getEntity();
		} else {
			return;
		}
		float jitterLevel = effectLevel;
		if (state == State.OUT) {
			jitterLevel *= jitterLevel;
		}
		float maxRangeBonus = 25f;
		float jitterRangeBonus = jitterLevel * maxRangeBonus;
		ship.setJitterUnder(this, JITTER_UNDER_COLOR, jitterLevel, 11, 0f, 3f + jitterRangeBonus);
		ship.setJitter(this, JITTER_COLOR, jitterLevel, 4, 0f, 0 + jitterRangeBonus);
		
		if (effectLevel >= 1) {
			Vector2f target = ship.getMouseTarget();
			if (ship.getShipAI() != null && ship.getAIFlags().hasFlag(AIFlags.SYSTEM_TARGET_COORDS)){
				target = (Vector2f) ship.getAIFlags().getCustom(AIFlags.SYSTEM_TARGET_COORDS);
			}
			if (target != null) {
				float dist = Misc.getDistance(ship.getLocation(), target);
				float max = getMineRange(ship) + ship.getCollisionRadius();
				if (dist > max) {
					float dir = Misc.getAngleInDegrees(ship.getLocation(), target);
					target = Misc.getUnitVectorAtDegreeAngle(dir);
					target.scale(max);
					Vector2f.add(target, ship.getLocation(), target);
				}
				if (target != null) {
					
					for (int i=0; i < CHARGE_COUNT; i++) {
						spawnMine(ship, target);
					}
					Vector2f soundVel = MathUtils.getRandomPointInCircle(null, 5f);
					Global.getSoundPlayer().playSound("mine_teleport", 1f, 1f, target, soundVel);
				}
			}
		}
	}
	
	public void unapply(MutableShipStatsAPI stats, String id) {
	}
	
	public void spawnMine(ShipAPI source, Vector2f mineLoc) {
		CombatEngineAPI engine = Global.getCombatEngine();
		Vector2f currLoc = MathUtils.getRandomPointInCircle(mineLoc, MINE_RADIUS);
		
		//engine.spawnProjectile(source, null, "domhist_phase_depth_charge_wpn", currLoc, (float) Math.random() * 360f, null);
		
		DamagingProjectileAPI charge = (DamagingProjectileAPI) engine.spawnProjectile(source, null, 
				  "domhist_phase_depth_charge_wpn", 
				  currLoc, 
				  (float) Math.random() * 360f, null);
		
		if (source != null) {
			Global.getCombatEngine().applyDamageModifiersToSpawnedProjectileWithNullWeapon(
					source, WeaponType.MISSILE, false, charge.getDamage());
		}
				
		Vector2f chargeVel = charge.getVelocity();
		
		Vector2f randomVel1 = MathUtils.getRandomPointInCircle(chargeVel, 5f);
        engine.addNebulaSmokeParticle(currLoc,
        		randomVel1,
        		MathUtils.getRandomNumberInRange(20f, 30f), //size
        		1.9f, //end mult
        		0.6f, //ramp fraction
        		0.25f, //full bright fraction
        		1.0f, //duration // 0.5
        		new Color(185,100,195,80)); //100,185,195,80
		
        Global.getCombatEngine().addSmoothParticle(currLoc,
        		chargeVel,
        		MathUtils.getRandomNumberInRange(45f, 45f), //size
        		1.0f, //brightness
        		1.0f, //duration
        		new Color(190,60,255,215));
        
        for (int i=0; i < 2; i++) {
        	Vector2f randomVel2 = MathUtils.getRandomPointInCircle(chargeVel, 5f);
            Global.getCombatEngine().addSmoothParticle(currLoc,
            		randomVel2,
            		MathUtils.getRandomNumberInRange(25f, 35f), //size
            		1.0f, //brightness
            		0.35f, //duration
            		new Color(70,195,225,215));
            
            for (int j=0; j < 8; j++) {
            			Vector2f randomVel3 = MathUtils.getRandomPointOnCircumference(chargeVel, MathUtils.getRandomNumberInRange(40f, 100f));
            			Global.getCombatEngine().addSmoothParticle(currLoc,
            				randomVel3,
            				MathUtils.getRandomNumberInRange(3f, 8f), //size
            				0.7f, //brightness
            				0.55f, //duration
            				new Color(150,100,255,255));
            }
        }
        
	}

	@Override
	public String getInfoText(ShipSystemAPI system, ShipAPI ship) {
		if (system.isOutOfAmmo()) return null;
		if (system.getState() != SystemState.IDLE) return null;
		Vector2f target = ship.getMouseTarget();
		if (target != null) {
			float dist = Misc.getDistance(ship.getLocation(), target);
			float max = getMineRange(ship) + ship.getCollisionRadius();
			if (dist > max) {
				return "OUT OF RANGE";
			} else {
				return "READY";
			}
		}
		return null;
	}

	@Override
	public boolean isUsable(ShipSystemAPI system, ShipAPI ship) {
		return ship.getMouseTarget() != null;
	}
	
	public float getFuseTime() {
		return 1f;
	}

	@Override
	public float getMineRange(ShipAPI ship) {
		return getRange(ship);
	}	
}