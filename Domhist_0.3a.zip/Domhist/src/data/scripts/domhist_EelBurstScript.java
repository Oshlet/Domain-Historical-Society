package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.input.InputEventAPI;
import org.jetbrains.annotations.NotNull;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.Color;
import java.util.List;

public class domhist_EelBurstScript extends BaseEveryFrameCombatPlugin {

	private static final float TIMER = 1.2f; // the time the MIRV lasts before MIRVing
	
	private MissileAPI missile;
	private float timeCounter;
	private float rocketDelay;
	
	public domhist_EelBurstScript(@NotNull MissileAPI missile) {
		this.missile = missile;
	}

	//Main advance method
	@Override
	public void advance(float amount, List<InputEventAPI> events) {
		//Sanity checks
		if (Global.getCombatEngine() == null) {
			return;
		}
		if (Global.getCombatEngine().isPaused()) {
			amount = 0f;
		}
		  CombatEngineAPI engine = Global.getCombatEngine();

		//Checks if our script should be removed from the combat engine
		if (missile == null || missile.didDamage() || missile.isFading() || !Global.getCombatEngine().isEntityInPlay(missile)) {
			engine.removePlugin(this);
			return;
		}
		
		//Ticks up our timer, and if over the detonation time, do the MIRV
		timeCounter+=amount;
		if (timeCounter > TIMER) {
			
			for (int i=0; i < 5;) {
	            rocketDelay -= amount;
	            
	            while (rocketDelay <= 0f) {
	            	rocketDelay += 0.15f;
	            	
	                Vector2f eelRandomVel = MathUtils.getRandomPointInCircle(missile.getVelocity(), 20f);
	                float randomSize = MathUtils.getRandomNumberInRange(35f, 45f);
	                
	                engine.spawnProjectile(missile.getWeapon().getShip(), missile.getWeapon(), "domhist_rktmirv_dummy", missile.getLocation(), missile.getFacing(), eelRandomVel);
	                
	                engine.addNebulaParticle(missile.getLocation(),
	                		missile.getVelocity(),
	                randomSize, //size
	                2.2f, //end mult
	                0.5f, //ramp fraction
	                0.75f, //full bright fraction
	                0.9f, //duration
	                new Color(90,85,80,105),
	                true);
	                
	                Global.getSoundPlayer().playSound("annihilator_fire", 1f, 1f, missile.getLocation(), missile.getVelocity());
	                
	                i++;
	              }
			}
			
            if (timeCounter >= (TIMER + (0.65f))) {
            	engine.removeEntity(missile);
            }
			
		}
	}
}