package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.CampaignPlugin;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;

import data.scripts.ai.domhist_TicketMagicMissileAI;
import data.scripts.world.systems.domhist_albionGen;
import data.scripts.world.systems.domhist_avalonGen;
import data.scripts.world.systems.domhist_brittanyGen;
import exerelin.campaign.SectorManager;

public class domhist_ModPlugin extends BaseModPlugin {

	public static final String TICKET_MISSILE_ID = "domhist_wormwood_mssl";
	
    //New game stuff
    @Override
    public void onNewGame() {
        SectorAPI sector = Global.getSector();

        //If we have Nexerelin and random worlds enabled, don't spawn our manual systems
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (!haveNexerelin || SectorManager.getManager().isCorvusMode()){
            new domhist_albionGen().generate(sector);
            new domhist_brittanyGen().generate(sector);
            new domhist_avalonGen().generate(sector);
        }
        
        SharedData.getData().getPersonBountyEventData().addParticipatingFaction("domhist");

        FactionAPI domhist = sector.getFaction("domhist");
        FactionAPI player = sector.getFaction(Factions.PLAYER);
        FactionAPI hegemony = sector.getFaction(Factions.HEGEMONY);
        FactionAPI tritachyon = sector.getFaction(Factions.TRITACHYON);
        FactionAPI pirates = sector.getFaction(Factions.PIRATES);
        FactionAPI independent = sector.getFaction(Factions.INDEPENDENT); 
        FactionAPI church = sector.getFaction(Factions.LUDDIC_CHURCH);
        FactionAPI path = sector.getFaction(Factions.LUDDIC_PATH);   	
        FactionAPI diktat = sector.getFaction(Factions.DIKTAT); 
        FactionAPI kol = sector.getFaction(Factions.KOL);	
        FactionAPI persean = sector.getFaction(Factions.PERSEAN);
        FactionAPI guard = sector.getFaction(Factions.LIONS_GUARD);
        FactionAPI remnant = sector.getFaction(Factions.REMNANTS);
        FactionAPI derelict = sector.getFaction(Factions.DERELICT);

        //vanilla factions
        domhist.setRelationship(hegemony.getId(), RepLevel.FRIENDLY);
        domhist.setRelationship(player.getId(), 0);
        domhist.setRelationship(pirates.getId(), -0.75f);
        
        domhist.setRelationship(independent.getId(), 0f);
        
        domhist.setRelationship(tritachyon.getId(), -0.25f);
        
        domhist.setRelationship(kol.getId(), -0.25f);
        domhist.setRelationship(path.getId(), RepLevel.HOSTILE);
        domhist.setRelationship(church.getId(), -0.25f);
        
        domhist.setRelationship(persean.getId(), -0.5f);
        domhist.setRelationship(guard.getId(), -0.2f);
        domhist.setRelationship(diktat.getId(), 0.0f);
        
        //environment
        domhist.setRelationship(remnant.getId(), RepLevel.HOSTILE);
        domhist.setRelationship(derelict.getId(), RepLevel.FRIENDLY);
        
        // mod factions
		domhist.setRelationship("al_ars", -0.5f);
        domhist.setRelationship("almighty_dollar", 0.1f);
        domhist.setRelationship("blackrock_driveyards", -0.25f);
        domhist.setRelationship("blade_breakers", -1.0f);
        domhist.setRelationship("cabal", -0.8f);
        domhist.setRelationship("communist_clouds", -0.60f);
        domhist.setRelationship("dassault_mikoyan", 0.15f);
        domhist.setRelationship("diableavionics", -0.6f);
        domhist.setRelationship("exalted", -1.00f);
        domhist.setRelationship("gmda", -0.25f);
        domhist.setRelationship("gmda_patrol", -0.25f);
		domhist.setRelationship("HMI", -0.25f);
		domhist.setRelationship("interstellarimperium", -0.8f);
        domhist.setRelationship("ironshell", 0.6f);
        domhist.setRelationship("kadur_remnant", -0.80f);
        domhist.setRelationship("keruvim", -0.50f);
        domhist.setRelationship("kyeltziv", -0.25f);
        domhist.setRelationship("magellan_protectorate", -0.80f);
        domhist.setRelationship("mayasura", -0.90f);
        domhist.setRelationship("prv", -0.25f);
        domhist.setRelationship("ocua", -0.25f);
        domhist.setRelationship("ORA", -0.25f);
        domhist.setRelationship("rb", -0.60f);
        domhist.setRelationship("scalartech", -0.25f);
        domhist.setRelationship("science_fuckers", -0.50f);
        domhist.setRelationship("SCY", -0.25f);
        domhist.setRelationship("shadow_industry", -0.60f);
        domhist.setRelationship("star_federation", -0.40f);
        domhist.setRelationship("sylphon", -0.20f);
        domhist.setRelationship("tiandong", 0f);
        domhist.setRelationship("tahlan_legioinfernalis", -1.0f);
        domhist.setRelationship("unitedpamed", 0.2f);
        domhist.setRelationship("vanidad", 0.5f);
        domhist.setRelationship("vic", 0.4f);
        domhist.setRelationship("warhawk_republic", -0.60f);
        domhist.setRelationship("xhanempire", -0.60f);
        domhist.setRelationship("xlu", -0.80f);
        domhist.setRelationship("yrxp", -0.5f);
        domhist.setRelationship("uaf", -1f);

        domhist.setRelationship("kyeltziv", -0.25f);
        
        // base rep levels loosely copied from Seriouslywhatisthewholepointofthisisweartoluddiwillmakethispersoneattheirshoe (hi Tim! :wave:)
        
        domhist.setRelationship("roider", -0.6f);
        domhist.setRelationship("exipirated", -0.6f);
        domhist.setRelationship("draco", -0.75f);
        domhist.setRelationship("fang", -0.75f);
        domhist.setRelationship("junk_pirates", -0.6f);
        domhist.setRelationship("junk_pirates_hounds", -0.6f);
        domhist.setRelationship("junk_pirates_junkboys", -0.6f);
        domhist.setRelationship("junk_pirates_technicians", -0.6f);
        domhist.setRelationship("the_cartel", -0.6f);
        domhist.setRelationship("nullorder", -0.6f);
        domhist.setRelationship("templars", -0.6f);
        
        domhist.setRelationship("new_galactic_order", -1.0f);
        
        domhist.setRelationship("crystanite_pir", -0.6f);
        domhist.setRelationship("infected", -0.6f);
        domhist.setRelationship("TF7070_D3C4", -0.6f);
        domhist.setRelationship("minor_pirate_1", -0.6f);
        domhist.setRelationship("minor_pirate_2", -0.6f);
        domhist.setRelationship("minor_pirate_3", -0.6f);
        domhist.setRelationship("minor_pirate_4", -0.6f);
        domhist.setRelationship("minor_pirate_5", -0.6f);
        domhist.setRelationship("minor_pirate_6", -0.6f);
        domhist.setRelationship("Coalition", -0.25f);
        domhist.setRelationship("mayorate", -0.5f);
        
    }
    
    @Override
    public PluginPick<MissileAIPlugin> pickMissileAI(MissileAPI missile, ShipAPI launchingShip) {
        switch (missile.getProjectileSpecId()) {
            case TICKET_MISSILE_ID:
                return new PluginPick<MissileAIPlugin>(new domhist_TicketMagicMissileAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            default:
                return null;
        }
    }
    
    /*
    @Override
    public void onNewGameAfterEconomyLoad() {
        MarketAPI market = Global.getSector().getEconomy().getMarket("albion_1_market");
        if (market != null) {
            PersonAPI admin = Global.getFactory().createPerson();
            admin.setFaction("domhist");
            admin.setGender(FullName.Gender.MALE);
            admin.setPostId(Ranks.POST_FACTION_LEADER);
            admin.setRankId(Ranks.FACTION_LEADER);
            admin.getName().setFirst("Sir");
            admin.getName().setLast("Norwood");
            admin.setPortraitSprite("graphics/portraits/domhist_norwood.png");

            admin.getStats().setSkillLevel(Skills.INDUSTRIAL_PLANNING, 3);
            admin.getStats().setSkillLevel(Skills.PLANETARY_OPERATIONS, 3);
            admin.getStats().setSkillLevel(Skills.SPACE_OPERATIONS, 3);

            market.setAdmin(admin);
            market.getCommDirectory().addPerson(admin, 0);
            market.addPerson(admin);
        }
    }
    */   
}