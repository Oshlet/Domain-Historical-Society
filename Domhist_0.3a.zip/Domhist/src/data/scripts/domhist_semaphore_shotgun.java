package data.scripts;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;

public class domhist_semaphore_shotgun implements OnFireEffectPlugin {

    public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
            for (int i=0; i < 8; i++) {
                Vector2f vel = (Vector2f) (projectile.getVelocity());
                Vector2f semaphoreRandomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(11f, 111f));
                semaphoreRandomVel.x += vel.x;
                semaphoreRandomVel.y += vel.y;
                engine.spawnProjectile(weapon.getShip(), weapon, "domhist_semaphore_dummy", projectile.getLocation(), projectile.getFacing(), semaphoreRandomVel);
            }
            engine.removeEntity(projectile);
    }
  }