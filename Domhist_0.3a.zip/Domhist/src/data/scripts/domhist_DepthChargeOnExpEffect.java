package data.scripts;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.ProximityExplosionEffect;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.util.Misc;

public class domhist_DepthChargeOnExpEffect implements ProximityExplosionEffect {
	
	private static final float RANGE = 302500f; // 550 squared
	private static final float FLUX_DAMAGE = 600f;
	private boolean VALID = false;
	
	public void onExplosion(DamagingProjectileAPI explosion, DamagingProjectileAPI originalProjectile) {
		
		CombatEngineAPI engine = Global.getCombatEngine();
		ShipAPI ship = originalProjectile.getSource();
		Vector2f point = explosion.getLocation(); 
		
		for (ShipAPI target_ship : engine.getShips()) {
			// check if the ship is a valid target
			if (target_ship.isHulk() || target_ship.getOwner() == ship.getOwner()) {
				continue;
			}
			
			float tag_radius = target_ship.getCollisionRadius();
			
			// check if the ship is phased and in range, if yes to both, then it's valid
			if ((MathUtils.getDistanceSquared(point, target_ship.getLocation()) <= (RANGE + (tag_radius * tag_radius))) && (target_ship.isPhased())) {
				VALID = true;
			} else {
				VALID = false;
			}
			
			// if the target ship is classed as valid, make it eat some hardflux, slow it a little, and spawn some fx 
			if (VALID){
				target_ship.getFluxTracker().increaseFlux(FLUX_DAMAGE, true);
				
				Vector2f vel = target_ship.getVelocity();
				vel.x = vel.x * 0.95f;
				vel.y = vel.y * 0.95f;
				target_ship.getVelocity().set(vel);
				
				//spawn fx on the phase ship that is eating flux
				Vector2f fxPoint = target_ship.getLocation();
				float fxScale = target_ship.getCollisionRadius() / 50f; // this is so we scale the level of effects generated with the size of what we're zapping
				
				// an arc from the explosion to the zapped target
				Vector2f zapPoint = MathUtils.getRandomPointInCircle(fxPoint, (fxScale * 10f));
				engine.spawnEmpArcVisual(point, explosion, zapPoint, target_ship, 9f,
						new Color(155,70,130,40),
						new Color(255,225,255,44));
				
				for (int j=0; j < fxScale; j++) {
					
					float angleRandom1 = MathUtils.getRandomNumberInRange(0, 360);
		            float distanceRandom1 = MathUtils.getRandomNumberInRange(0.35f, 0.8f);
		            Vector2f Dir1 = Misc.getUnitVectorAtDegreeAngle(angleRandom1);
		            Vector2f arcPoint1 = new Vector2f(fxPoint.x + Dir1.x * tag_radius * distanceRandom1, fxPoint.y + Dir1.y * tag_radius * distanceRandom1);
		            
		            float angleRandom2 = MathUtils.getRandomNumberInRange(40, 80);
		            float distanceRandom2 = MathUtils.getRandomNumberInRange(0.9f, 1.1f);
		            Vector2f Dir2 = Misc.getUnitVectorAtDegreeAngle(angleRandom1 + angleRandom2);
		            Vector2f arcPoint2 = new Vector2f(fxPoint.x + Dir2.x * tag_radius * (distanceRandom1 * distanceRandom2), fxPoint.y + Dir2.y * tag_radius * (distanceRandom1 * distanceRandom2));
					
		            engine.spawnEmpArcVisual(arcPoint1, target_ship, arcPoint2, target_ship, 10f,
							new Color(155,70,130,50),
							new Color(255,225,255,55));
				}
				
		        Global.getSoundPlayer().playSound("tachyon_lance_emp_impact", 0.8f, 1.2f, point, target_ship.getVelocity());
		        
		        for (int i=0; i < (fxScale * 20); i++) {
		        	
		        	Vector2f sparkPoint = MathUtils.getRandomPointInCircle(fxPoint, (fxScale * 30f));
					Vector2f sparkVel = MathUtils.getRandomPointOnCircumference(target_ship.getVelocity(), MathUtils.getRandomNumberInRange(30f, 90f));
					Global.getCombatEngine().addSmoothParticle(sparkPoint,
							sparkVel,
						MathUtils.getRandomNumberInRange(3f, 8f), //size
						0.6f, //brightness
						0.75f, //duration
						new Color(155,70,130,255)); // 100,150,255,255
		        }
		        
			} else {
				continue;
			}
		}
		
		//spawn vfx on the explosion point
		for (int i=0; i < 2; i++) {
			Vector2f smokeVel = MathUtils.getRandomPointInCircle(null, 5f);
	        engine.addNebulaSmokeParticle(point,
	        		smokeVel,
	        		MathUtils.getRandomNumberInRange(120f, 160f), //size
	        		2.1f, //end mult
	        		0.6f, //ramp fraction
	        		0.3f, //full bright fraction
	        		1.75f, //duration
	        		new Color(185,100,195,45));
	        
	        for (int j=0; j < 11; j++) {
	        	Vector2f sparkPoint = MathUtils.getRandomPointInCircle(point, 15);
				Vector2f sparkVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(30f, 90f));
				Global.getCombatEngine().addSmoothParticle(sparkPoint,
						sparkVel,
					MathUtils.getRandomNumberInRange(3f, 8f), //size
					0.5f, //brightness
					1.1f, //duration
					new Color(100,150,255,200));
				
				for (int k=0; k < 3; k++) {
		        	
		        	Vector2f sparkPoint2 = MathUtils.getRandomPointInCircle(point, 50);
					Vector2f sparkVel2 = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(30f, 90f));
					Global.getCombatEngine().addSmoothParticle(sparkPoint2,
							sparkVel2,
						MathUtils.getRandomNumberInRange(3f, 8f), //size
						0.3f, //brightness
						0.75f, //duration
						new Color(155,70,130,125));
		        }
				
	        }   
		}		
	}
}