package data.scripts;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.IntervalUtil;

public class domhist_gaugerBeamEffect implements BeamEffectPlugin {

	private IntervalUtil procInterval = new IntervalUtil(0.2f, 0.2f);
	private IntervalUtil sparkInterval = new IntervalUtil(0.15f, 0.3f); // slightly random timing because it will look a bit cooler i guess? 
	private boolean wasZero = true;
	private boolean wasZeroSpark = true;
	
	public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
		
		CombatEntityAPI target = beam.getDamageTarget();
		
		if (target != null) {
			float procDur = beam.getDamage().getDpsDuration();
			if (!wasZero) {
				procDur = 0;
			}
			wasZero = beam.getDamage().getDpsDuration() <= 0;
			
			procInterval.advance(procDur);
			
			if (procInterval.intervalElapsed()) {
				Vector2f point = beam.getRayEndPrevFrame();

                Global.getCombatEngine().addSmoothParticle(point,
                	target.getVelocity(),
                    30f, //size
                    1.0f, //brightness
                    0.25f, //duration
                    new Color(180,80,50,100));

  				for (int i=0; i < 2; i++) {
	                  Vector2f randomVel1 = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(32f, 80f));
	                  Vector2f sparkVel1 = target.getVelocity();
	                  randomVel1.x += sparkVel1.x;
	                  randomVel1.y += sparkVel1.y;
	                  Vector2f point1 = MathUtils.getRandomPointInCircle(point, 4f);
	                  
	                  float randomSize1 = MathUtils.getRandomNumberInRange(2f, 10f);
	                  Global.getCombatEngine().addSmoothParticle(point1,
	                      randomVel1,
	                      randomSize1, //size
	                      1.0f, //brightness
	                      0.4f, //duration
	                      new Color(255,125,55,60));
	  				for (int j=0; j < 2; j++) {
		                  Vector2f randomVel2 = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(32f, 80f));
		                  Vector2f sparkVel2 = target.getVelocity();
		                  randomVel2.x += sparkVel2.x;
		                  randomVel2.y += sparkVel2.y;
		                  Vector2f point2 = MathUtils.getRandomPointInCircle(point, 5f);
		                  
		                  float randomSize2 = MathUtils.getRandomNumberInRange(3f, 15f);
		                  Global.getCombatEngine().addSmoothParticle(point2,
		                      randomVel2,
		                      randomSize2, //size
		                      1.0f, //brightness
		                      0.5f, //duration
		                      new Color(160,120,50,55));
	  				}
  				}
			}	
		}
		
		if (target instanceof ShipAPI) {
			float blastDur = beam.getDamage().getDpsDuration();
			if (!wasZeroSpark) {
				blastDur = 0;
			}
			wasZeroSpark = beam.getDamage().getDpsDuration() <= 0;
			
			sparkInterval.advance(blastDur);
			
			if (sparkInterval.intervalElapsed()) {
				boolean hitShield = target.getShield() != null && target.getShield().isWithinArc(beam.getTo());
				
				//engine.addFloatingText(beam.getTo(), "STINKY", 20f, Color.yellow, target, 2f, 2f);
				
				if (!hitShield) {
					Vector2f point = beam.getRayEndPrevFrame();
					
					float damage = MathUtils.getRandomNumberInRange(20f, 40f) * beam.getSource().getMutableStats().getEnergyWeaponDamageMult().getMult();
					
					
					DamagingExplosionSpec sparkBlast = new DamagingExplosionSpec(0.2f,
							damage * 0.45f,
							damage * 0.4f,
			                damage, // dmg inner
			                damage * 0.6f, // dmg outer
			                CollisionClass.PROJECTILE_FF,
			                CollisionClass.PROJECTILE_FIGHTER,
			                1f,
			                4f,
			                0.4f,
			                (int) (damage * 0.45f),
			                new Color(160,80,40,160), // particle color
			                new Color(255,90,50,130)); // explosion color
					sparkBlast.setDamageType(DamageType.FRAGMENTATION);
					sparkBlast.setShowGraphic(true);
					sparkBlast.setUseDetailedExplosion(false);
			        
			        Vector2f randomPoint = MathUtils.getRandomPointInCircle(point, 16f);
			        
			        engine.addNebulaSmokeParticle(randomPoint,
			        		target.getVelocity(),
			        		MathUtils.getRandomNumberInRange(10f, 12f), //size
			        		1.9f, //end mult
			        		0.6f, //ramp fraction
			        		0.25f, //full bright fraction
			        		0.5f, //duration
			        		new Color(125,45,25,65));
			        
			        engine.spawnDamagingExplosion(sparkBlast,beam.getSource(),randomPoint,false);
			        //Global.getSoundPlayer().playSound("explosion_flak", 0.7f, 0.25f, randomPoint, target.getVelocity());
				}
			}
		}
	}
}