package data.scripts.world.systems;

import static com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel.FULL;
import static com.fs.starfarer.api.impl.campaign.ids.Skills.INDUSTRIAL_PLANNING;
import static data.scripts.world.systems.domhist_AddMarketplace.createAdminist;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

public class domhist_albionGen  {
  
    public void generate(SectorAPI sector) {

        StarSystemAPI system = sector.createStarSystem("Albion");
        
        system.getLocation().set(14000, -30100);
        
        system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");

        PlanetAPI albion_star = system.initStar("domhist_albion",
                "star_orange",
                705f,
                690f);

        albion_star.setName("Albion");

        system.setLightColor(new Color(235, 195, 155));


        // First Planet
        PlanetAPI albion_1 = system.addPlanet("domhist_camelot",
                albion_star,
                "Camelot",
                "terran-eccentric",
                300f, //starting angle
                210f, //size
                3400f, // orbit radius
                376f); // orbit time
        albion_1.setCustomDescriptionId("domhist_planet_camelot");

        
        SectorEntityToken albion_round_table = system.addCustomEntity("domhist_round_table", "The Round Table", "station_side07", "domhist");
        albion_round_table.setCircularOrbitPointingDown(albion_1, 30f, 305f, 101f);
        albion_round_table.setCustomDescriptionId("domhist_station_round_table");
        
//        SectorEntityToken albion_starfortress = system.addCustomEntity("domhist_cam_starfort", "Camelot Star Fortress", "station_side05", "domhist");
//        albion_round_table.setCircularOrbitPointingDown(albion_1, 90, 245f ,120f);
        
         ArrayList<SectorEntityToken> camelotStationList = new ArrayList<>(Arrays.asList(albion_round_table));

/*
        ArrayList<SectorEntityToken> camelotStationList = new ArrayList<>();
        camelotStationList.add(albion_starfortress);
        camelotStationList.add(albion_round_table);
*/

        MarketAPI albion_1_market = domhist_AddMarketplace.addMarketplace("domhist",
                albion_1,
                camelotStationList,
                "Camelot",
                6,
                new ArrayList<String>(
                    Arrays.asList(
                        Conditions.POPULATION_6,
                        Conditions.HABITABLE,
                        Conditions.EXTREME_WEATHER, // U HAP NOW TIM
                        "domhist_clogged_atmosphere", // Conditions.POLLUTION,
                        "domhist_hege_sanctioned_logi", // funny domhist accessibility hack :)
                        Conditions.FARMLAND_ADEQUATE,
                        Conditions.ORE_SPARSE,
                        Conditions.ORGANICS_TRACE
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Submarkets.SUBMARKET_OPEN,
                        Submarkets.SUBMARKET_STORAGE,
                        Submarkets.SUBMARKET_BLACK
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Industries.POPULATION,
                        Industries.MEGAPORT,
                        Industries.FARMING,
                        Industries.LIGHTINDUSTRY,
                        "commerce",
                        Industries.STARFORTRESS,
                        Industries.GROUNDDEFENSES,
                        Industries.PATROLHQ
                    )
                ),
                true,
                false);

        
        final String NORWOOD_PORTRAIT = "graphics/portraits/domhist_norwood.png";
        
        PersonAPI dh_leader = createAdminist(albion_1_market);
        dh_leader.getStats().setSkillLevel(INDUSTRIAL_PLANNING, 3);
        // dh_leader.getStats().setSkillLevel(PLANETARY_OPERATIONS, 3);
        dh_leader.setPortraitSprite(NORWOOD_PORTRAIT);
        dh_leader.setPostId("fleetCommander"); //"factionLeader"
        dh_leader.setRankId("groundGeneral");	//"factionLeader"
        dh_leader.getName().setFirst("Sir");
        dh_leader.getName().setLast("Norwood");
        albion_1_market.setSurveyLevel(FULL);
        

        SectorEntityToken albion_relay = system.addCustomEntity("domhist_albion_relay", // unique id
                "Albion Relay", // name - if null, defaultName from custom_entities.json will be used
                "comm_relay", // type of object, defined in custom_entities.json
                "domhist"); // faction
        albion_relay.setCircularOrbitPointingDown( albion_star, 67f, 4300, 360);
        
        SectorEntityToken albion_buoy = system.addCustomEntity("domhist_albion_buoy", // unique id
                "Albion Buoy", // name - if null, defaultName from custom_entities.json will be used
                "nav_buoy", // type of object, defined in custom_entities.json
                "domhist"); // faction
        albion_buoy.setCircularOrbitPointingDown( albion_star, 187f, 4100, 360);
        
        SectorEntityToken albion_array = system.addCustomEntity("domhist_albion_relay", // unique id
                "Albion Array", // name - if null, defaultName from custom_entities.json will be used
                "sensor_array", // type of object, defined in custom_entities.json
                "domhist"); // faction
        albion_array.setCircularOrbitPointingDown( albion_star, 307f, 4200, 360);
        

        // Second Planet
        PlanetAPI albion_2 = system.addPlanet("domhist_goemagot",
                albion_star,
                "Goemagot",
                "gas_giant",
                100f, //starting angle
                333f, //size
                5300f, // orbit radius
                469f); // orbit time
        albion_2.setCustomDescriptionId("domhist_planet_goemagot");

        MarketAPI albion_2_market = domhist_AddMarketplace.addMarketplace("domhist",
                albion_2,
                null,
                "Goemagot",
                5,
                new ArrayList<String>(
                    Arrays.asList(
                        Conditions.POPULATION_5,
                        Conditions.EXTREME_WEATHER,
                        Conditions.HIGH_GRAVITY,
                        "domhist_hege_sanctioned_logi", // funny domhist accessibility hack :)
                        Conditions.VOLATILES_ABUNDANT,
                        Conditions.RUINS_EXTENSIVE
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Submarkets.GENERIC_MILITARY,
                        Submarkets.SUBMARKET_OPEN,
                        Submarkets.SUBMARKET_STORAGE,
                        Submarkets.SUBMARKET_BLACK
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Industries.POPULATION,
                        Industries.SPACEPORT,
                        Industries.MINING,
                        //Industries.TECHMINING, // U HAP NOW TIM
                        Industries.WAYSTATION,
                        Industries.HIGHCOMMAND,
                        Industries.HEAVYBATTERIES
                    )
                ),
                true,
                false);
        
        system.addRingBand(albion_2, "misc", "rings_special0", 		256f, 0, Color.white, 256f, 564, 200f);

        // Third Planet
        PlanetAPI albion_3 = system.addPlanet("domhist_caledonia",
                albion_star,
                "Caledonia",
                "irradiated",
                200f, //starting angle
                127f, //size
                6400f, // orbit radius
                534f); // orbit time
        albion_3.setCustomDescriptionId("domhist_planet_caledonia");

        MarketAPI albion_3_market = domhist_AddMarketplace.addMarketplace("domhist",
                albion_3,
                null,
                "Caledonia",
                6,
                new ArrayList<String>(
                    Arrays.asList(
                        Conditions.POPULATION_6,
                        Conditions.IRRADIATED,
                        "domhist_extreme_pollution",
                        "domhist_hege_sanctioned_logi", // funny domhist accessibility hack :)
                        Conditions.ORE_MODERATE,
                        Conditions.RARE_ORE_SPARSE
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Submarkets.SUBMARKET_OPEN,
                        Submarkets.SUBMARKET_STORAGE,
                        Submarkets.SUBMARKET_BLACK
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Industries.POPULATION,
                        Industries.MEGAPORT,
                        Industries.REFINING,
                        //Industries.HEAVYINDUSTRY,
                        Industries.ORBITALSTATION_MID
                    )
                ),
                true,
                false);
      albion_3_market.addIndustry(Industries.HEAVYINDUSTRY,new ArrayList<String>(Arrays.asList(Items.CORRUPTED_NANOFORGE)));


        SectorEntityToken albion_station = system.addCustomEntity("domhist_merlin", "Merlin Embassy", "station_lowtech2", "hegemony");
        albion_station.setCircularOrbitPointingDown(albion_star, 30, 6500f ,534f);
        albion_station.setCustomDescriptionId("domhist_station_merlin");
			  albion_station.setInteractionImage("illustrations", "hound_hangar");
			  MarketAPI albion_station_market = domhist_AddMarketplace.addMarketplace("hegemony",
                albion_station, null,
                "Merlin Embassy",
                3,
                new ArrayList<String>(
                        Arrays.asList(
                                Conditions.POPULATION_3,
                                Conditions.OUTPOST
                        )
                ),
                new ArrayList<String>(
                        Arrays.asList(
                                Submarkets.SUBMARKET_OPEN,
                                Submarkets.SUBMARKET_STORAGE,
                                Submarkets.SUBMARKET_BLACK
                        )
                ),
                new ArrayList<String>(
                        Arrays.asList(
                                Industries.POPULATION,
                                Industries.SPACEPORT,
                                Industries.WAYSTATION,
                                Industries.PATROLHQ,
                                Industries.BATTLESTATION
                        )
                ),
                true,
                false);

			  

			  //Inner system jump point
			  JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("domhist_brittany_inner_jump", "Brittany Inner Jump Point");
			  jumpPoint1.setCircularOrbit(albion_star, 34, 2430, 182);
			  system.addEntity(jumpPoint1);
		        
			  
			  // thick ring around caledonia
			  
			  system.addRingBand(albion_3, "misc", "rings_dust0", 		256f, 0, Color.white, 160f, 500, 70f);
			  system.addRingBand(albion_3, "misc", "rings_dust0", 		256f, 1, Color.white, 160f, 650, 80f);
			  system.addRingBand(albion_3, "misc", "rings_dust0", 		256f, 0, Color.white, 180f, 800, 90f);
			  
			  system.addAsteroidBelt(albion_3, 11, 600, 155, 80, 110, Terrain.ASTEROID_BELT, null);
			  system.addAsteroidBelt(albion_3, 15, 750, 155, 80, 110, Terrain.ASTEROID_BELT, null);
			  
			  // asteroids on either side of merlin
			  
			  SectorEntityToken albion_astfield_1 = system.addTerrain(Terrain.ASTEROID_FIELD,
						new AsteroidFieldParams(
							410f, // min radius
							590f, // max radius
							13, // min asteroid count
							27, // max asteroid count
							5f, // min asteroid radius 
							19f, // max asteroid radius
							null)); // null for default name
			  albion_astfield_1.setCircularOrbit(albion_star, 22f, 6520f, 534f);
			  
			  SectorEntityToken albion_astfield_2 = system.addTerrain(Terrain.ASTEROID_FIELD,
						new AsteroidFieldParams(
							410f, // min radius
							590f, // max radius
							13, // min asteroid count
							27, // max asteroid count
							5f, // min asteroid radius 
							19f, // max asteroid radius
							null)); // null for default name
			  albion_astfield_2.setCircularOrbit(albion_star, 38f, 6480f, 534f);
			  
			//add 2 "random" planets
				
				PlanetAPI albion_4 = system.addPlanet("domhist_tintagel",
						albion_star,
		                "Tintagel",
		                "barren_castiron",
		                86f, //starting angle
		                105, //size
		                6966f, // orbit radius
		                681f); // orbit time

		        PlanetAPI albion_5 = system.addPlanet("domhist_barras",
		        		albion_star,
		                "Barras",
		                "barren-bombarded",
		                279f, //starting angle
		                146f, //size
		                7273f, // orbit radius
		                718f); // orbit time
 
		        SectorEntityToken albion_astfield_3 = system.addTerrain(Terrain.ASTEROID_FIELD,
						new AsteroidFieldParams(
							420f, // min radius
							630f, // max radius
							23, // min asteroid count
							34, // max asteroid count
							4f, // min asteroid radius 
							15f, // max asteroid radius
							null)); // null for default name
		        albion_astfield_3.setCircularOrbit(albion_5, 0, 1, 69);
			  
			  

        // generates hyperspace destinations for in-system jump points
        system.autogenerateHyperspaceJumpPoints(true, true);

        //Finally cleans up hyperspace
        cleanup(system);
    }

    //Shorthand function for cleaning up hyperspace
    private void cleanup(StarSystemAPI system){
        HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
        NebulaEditor editor = new NebulaEditor(plugin);
        float minRadius = plugin.getTileSize() * 2f;

        float radius = system.getMaxRadiusInHyperspace();
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0f, 360f);
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0f, 360f, 0.25f);
    }
}
