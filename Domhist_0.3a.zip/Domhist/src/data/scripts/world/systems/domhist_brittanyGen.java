package data.scripts.world.systems;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.util.Misc;

public class domhist_brittanyGen  {
  
    public void generate(SectorAPI sector) {

        StarSystemAPI system = sector.createStarSystem("Brittany");
        
        system.getLocation().set(9400, -24600);
        
        system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");

        PlanetAPI brittany_star = system.initStar("domhist_brittany",
                "star_blue_giant",
                1100f,
                950f);

        brittany_star.setName("Brittany");

        system.setLightColor(new Color(205, 205, 255));


        // First Planet
        PlanetAPI brittany_1 = system.addPlanet("domhist_amorica",
                brittany_star,
                "Armorica",
                "barren-desert",
                30f,
                123f,
                4000f,
                341f);
        brittany_1.setCustomDescriptionId("domhist_planet_armorica");

        MarketAPI brittany_1_market = domhist_AddMarketplace.addMarketplace("domhist",
                brittany_1,
                null,
                "Armorica",
                5,
                new ArrayList<String>(
                    Arrays.asList(
                        Conditions.POPULATION_5,
                        Conditions.THIN_ATMOSPHERE,
                        Conditions.HOT,
                        Conditions.LOW_GRAVITY,
                        "domhist_hege_sanctioned_logi", // funny domhist accessibility hack :)
                        Conditions.ORE_RICH,
                        Conditions.RARE_ORE_MODERATE,
                        Conditions.ORGANICS_TRACE
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Submarkets.SUBMARKET_OPEN,
                        Submarkets.SUBMARKET_STORAGE,
                        Submarkets.SUBMARKET_BLACK
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Industries.POPULATION,
                        Industries.SPACEPORT,
                        Industries.MINING,
                        Industries.HEAVYBATTERIES,
                        Industries.ORBITALSTATION
                    )
                ),
                true,
                false);

        // Second Planet
        PlanetAPI brittany_2 = system.addPlanet("domhist_badon",
                brittany_star,
                "Badon",
                "water",
                120f,
                155f,
                5690f,
                441f);
        brittany_2.setCustomDescriptionId("domhist_planet_badon");

        MarketAPI brittany_2_market = domhist_AddMarketplace.addMarketplace("persean",
                brittany_2,
                null,
                "Badon",
                5,
                new ArrayList<String>(
                    Arrays.asList(
                        Conditions.POPULATION_5,
                        Conditions.HABITABLE, // U HAP NOW TIM
                        Conditions.INIMICAL_BIOSPHERE,
                        Conditions.WATER_SURFACE,
                        Conditions.VOLATILES_TRACE
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Submarkets.GENERIC_MILITARY,
                        Submarkets.SUBMARKET_OPEN,
                        Submarkets.SUBMARKET_STORAGE,
                        Submarkets.SUBMARKET_BLACK
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Industries.POPULATION,
                        Industries.SPACEPORT,
                        Industries.AQUACULTURE,
                        Industries.MILITARYBASE,
                        Industries.REFINING,
                        Industries.ORBITALSTATION_HIGH,
                        Industries.GROUNDDEFENSES
                    )
                ),
                true,
                false);


        SectorEntityToken brittany_relay = system.addCustomEntity("domhist_brittany_relay", // unique id
                "Brittany Relay", // name - if null, defaultName from custom_entities.json will be used
                "comm_relay", // type of object, defined in custom_entities.json
                "persean"); // faction
        brittany_relay.setCircularOrbitPointingDown( brittany_star, 30f, 5900, 441);
        
        SectorEntityToken brittany_buoy = system.addCustomEntity("domhist_brittany_buoy", // unique id
                "Brittany Buoy", // name - if null, defaultName from custom_entities.json will be used
                "nav_buoy", // type of object, defined in custom_entities.json
                "persean"); // faction
        brittany_buoy.setCircularOrbitPointingDown( brittany_star, 210f, 5900, 441);
        
        /*
        SectorEntityToken brittany_array = system.addCustomEntity("domhist_brittany_relay", // unique id
                "Brittany Array", // name - if null, defaultName from custom_entities.json will be used
                "sensor_array", // type of object, defined in custom_entities.json
                "persean"); // faction
        brittany_array.setCircularOrbitPointingDown( brittany_star, 335f, 5900, 379);
        */
        
        

        // Third Planet
        PlanetAPI brittany_3 = system.addPlanet("domhist_pleumer-bodou",
                brittany_star,
                "Pleumer-Bodou",
                "rocky_unstable",
                210f,
                139f,
                6900f,
                410f);
        brittany_3.setCustomDescriptionId("domhist_planet_pleumeur-bodou");

        MarketAPI brittany_3_market = domhist_AddMarketplace.addMarketplace("independent", brittany_3, null,
                "Pleumer-Bodou",
                5,
                new ArrayList<String>(
                        Arrays.asList(
                                Conditions.POPULATION_5,
                                Conditions.THIN_ATMOSPHERE,
                                Conditions.FARMLAND_ADEQUATE, // because hydrophonics doesn't exist >:(
                                //"hydroponics_complex", // fake, stinky condition that doesn't do anything >>>:(
                                Conditions.COLD,
                                Conditions.TECTONIC_ACTIVITY,
                                Conditions.POOR_LIGHT,
                                Conditions.RARE_ORE_ULTRARICH,
                                Conditions.RUINS_SCATTERED
                        )
                ),
                new ArrayList<String>(
                        Arrays.asList(
                                Submarkets.SUBMARKET_OPEN,
                                Submarkets.SUBMARKET_STORAGE,
                                Submarkets.SUBMARKET_BLACK
                        )
                ),
                new ArrayList<String>(
                        Arrays.asList(
                                Industries.POPULATION,
                                Industries.SPACEPORT,
                                Industries.MINING,
                                Industries.FARMING, // because hydrophonics doesn't exist >:(
                                Industries.PATROLHQ
                        )
                ),
                true,
                false);


        //Jump point for Badon
        JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("domhist_brittany_badon_jump", "Badon Jump Point");
        jumpPoint1.setCircularOrbit( system.getEntityById("domhist_badon"), 290, 1100, 169);
        jumpPoint1.setRelatedPlanet(brittany_3);
        system.addEntity(jumpPoint1);

        //Inner system jump point
        JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("domhist_brittany_inner_jump", "Brittany Inner System Jump Point");
        jumpPoint2.setCircularOrbit(brittany_star, 110, 2430, 182);
        system.addEntity(jumpPoint2);
        


        SectorEntityToken brittany_station = system.addCustomEntity("domhist_constantine", "Constantine Military Base", "station_lowtech3", "domhist");
        brittany_station.setCircularOrbitPointingDown(brittany_star, 310, 4800f ,381f);
        brittany_station.setCustomDescriptionId("domhist_station_constantine");
        MarketAPI brittany_station_market = domhist_AddMarketplace.addMarketplace("domhist",
                                brittany_station, null,
                "Constantine Military Base",
                4,
                new ArrayList<String>(
                        Arrays.asList(
                                Conditions.POPULATION_4,
                                "domhist_hege_sanctioned_logi", // funny domhist accessibility hack :)
                                Conditions.OUTPOST
                        )
                ),
                new ArrayList<String>(
                        Arrays.asList(
                                Submarkets.GENERIC_MILITARY,
                                Submarkets.SUBMARKET_OPEN,
                                Submarkets.SUBMARKET_STORAGE,
                                Submarkets.SUBMARKET_BLACK
                        )
                ),
                new ArrayList<String>(
                        Arrays.asList(
                                Industries.POPULATION,
                                Industries.SPACEPORT,
                                Industries.BATTLESTATION,
                                Industries.MILITARYBASE,
                                Industries.WAYSTATION
                        )
                ),
                true,
                false);

        // Add an Asteroid Field AND a Debris Field around Constantine
        
        DebrisFieldParams params = new DebrisFieldParams(
				294f, // field radius - should not go above 1000 for performance reasons
				0.5f, // density, visual - affects number of debris pieces
				10000000f, // duration in days 
				0f); // days the field will keep generating glowing pieces
		
		params.source = DebrisFieldSource.SALVAGE;
		params.baseSalvageXP = 250; // base XP for scavenging in field
		SectorEntityToken debris = Misc.addDebrisField(system, params, StarSystemGenerator.random);
		SalvageSpecialAssigner.assignSpecialForDebrisField(debris);
		
		// makes the debris field always visible on map/sensors and not give any xp or notification on being discovered
		debris.setSensorProfile(null);
		debris.setDiscoverable(null);
		debris.setCircularOrbit(brittany_station, 0, 1, 69);
        
		SectorEntityToken brittany_astfield_1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
					400f, // min radius
					600f, // max radius
					19, // min asteroid count
					31, // max asteroid count
					5f, // min asteroid radius 
					17f, // max asteroid radius
					null)); // null for default name
		brittany_astfield_1.setCircularOrbit(brittany_station, 0, 1, 69);
        
        
		// give the system a ring, between Pleumer-Bodou and Badon

		system.addRingBand(brittany_star, "misc", "rings_dust0", 		256f, 0, Color.white, 160f, 6250, 170f);
		system.addRingBand(brittany_star, "misc", "rings_asteroids0", 256f, 1, Color.white, 156f, 6350, 190f);
        system.addRingBand(brittany_star, "misc", "rings_dust0", 		256f, 1, Color.white, 160f, 6450, 180f);
        
		system.addAsteroidBelt(brittany_star, 100, 6350, 155, 80, 110, Terrain.ASTEROID_BELT, null);
		
		//add 2 "random" planets
		
		PlanetAPI brittany_4 = system.addPlanet("domhist_guingamp",
				brittany_star,
                "Guingamp",
                "frozen",
                301f, //starting angle
                173, //size
                8469f, // orbit radius
                481f); // orbit time

        PlanetAPI brittany_5 = system.addPlanet("domhist_uzel",
        		brittany_star,
                "Uzel",
                "frozen2",
                121f, //starting angle
                141f, //size
                8600f, // orbit radius
                481f); // orbit time
        
        system.addRingBand(brittany_star, "misc", "rings_ice0", 		256f, 0, Color.white, 230f, 7870, 310f);
        system.addRingBand(brittany_star, "misc", "rings_ice0", 		256f, 3, Color.white, 250f, 8060, 320f);
        system.addRingBand(brittany_star, "misc", "rings_ice0", 		256f, 0, Color.white, 270f, 8250, 330f);
		

        // generates hyperspace destinations for in-system jump points and makes an outer jump point
        system.autogenerateHyperspaceJumpPoints(true, true);

        //Finally cleans up hyperspace
        cleanup(system);
    }

    //Shorthand function for cleaning up hyperspace
    private void cleanup(StarSystemAPI system){
        HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
        NebulaEditor editor = new NebulaEditor(plugin);
        float minRadius = plugin.getTileSize() * 2f;

        float radius = system.getMaxRadiusInHyperspace();
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0f, 360f);
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0f, 360f, 0.25f);
    }
}
