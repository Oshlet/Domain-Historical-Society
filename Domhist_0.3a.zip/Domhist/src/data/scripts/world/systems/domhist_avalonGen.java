package data.scripts.world.systems;

import static com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel.FULL;
import static com.fs.starfarer.api.impl.campaign.ids.Skills.INDUSTRIAL_PLANNING;
import static data.scripts.world.systems.domhist_AddMarketplace.createAdminist;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.util.Misc;

public class domhist_avalonGen  {
  
    public void generate(SectorAPI sector) {

        StarSystemAPI system = sector.createStarSystem("Avalon");
        
        system.getLocation().set(19100, -27900);
        system.setAge(StarAge.AVERAGE);
        system.setType(StarSystemGenerator.StarSystemType.NEBULA);
        
        PlanetAPI avalon_star = system.initStar("domhist_avalon_center", "nebula_center_average", 0, 0);
        avalon_star.setSkipForJumpPointAutoGen(true);
        avalon_star.addTag(Tags.AMBIENT_LS);
		StarSystemGenerator.addSystemwideNebula(system, StarAge.YOUNG);
        
		system.removeEntity(avalon_star);
		StarCoronaTerrainPlugin coronaPlugin = Misc.getCoronaFor(avalon_star);
		if (coronaPlugin != null) {
			system.removeEntity(coronaPlugin.getEntity());
		}
		system.setStar(null);
		SectorEntityToken center = system.initNonStarCenter();
		center.addTag(Tags.AMBIENT_LS);
		
		system.setStar(avalon_star);

//        system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");

        
		SectorEntityToken domhist_lady = system.addCustomEntity("domhist_lady", "Lady of the Lake", "station_sporeship_derelict", "neutral");
		//domhist_lady.setFixedLocation(100f, 100f);
		domhist_lady.setCircularOrbitWithSpin(avalon_star, 10f, 650f, 365f, 13f, 34f);
		domhist_lady.setCustomDescriptionId("domhist_station_lady_of_the_lake");


        system.setLightColor(new Color(125, 125, 209));


        // First Planet
        PlanetAPI avalon_1 = system.addPlanet("domhist_morgan",
        		avalon_star,	//avalon_star,
                "Morgan",
                "terran-eccentric",
                300f, //starting angle
                170f, //size
                1999f, // orbit radius
                1337f); // orbit time
        avalon_1.setCustomDescriptionId("domhist_planet_morgan");
        
        avalon_1.setFixedLocation(2199f, 2690f);
        
        MarketAPI avalon_1_market = domhist_AddMarketplace.addMarketplace("domhist",
                avalon_1,
                null,
                "Morgan",
                3,
                new ArrayList<String>(
                    Arrays.asList(
                        Conditions.POPULATION_3,
                        Conditions.HABITABLE, // U HAP NOW TIM
                        Conditions.POOR_LIGHT,
                        Conditions.MILD_CLIMATE,
                        Conditions.LOW_GRAVITY,
                        "domhist_hege_sanctioned_logi", // funny domhist accessibility hack :)
                        Conditions.ORGANICS_TRACE,
                        Conditions.VOLATILES_TRACE,
                        Conditions.RUINS_VAST
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Submarkets.SUBMARKET_OPEN,
                        Submarkets.SUBMARKET_STORAGE,
                        Submarkets.SUBMARKET_BLACK
                    )
                ),
                new ArrayList<String>(
                    Arrays.asList(
                        Industries.POPULATION,
                        Industries.SPACEPORT,
                        Industries.WAYSTATION,
                        Industries.PATROLHQ,
                        Industries.ORBITALSTATION,
                        Industries.TECHMINING
                    )
                ),
                true,
                false);

        SectorEntityToken avalon_array = system.addCustomEntity("domhist_avalon_relay", // unique id
                "Avalon Array", // name - if null, defaultName from custom_entities.json will be used
                "sensor_array", // type of object, defined in custom_entities.json
                "domhist"); // faction
        avalon_array.setFixedLocation(2434f, 2046f);
        //avalon_array.setCircularOrbitPointingDown( avalon_1, 69f, 700, 99);

        SectorEntityToken avalon_relay = system.addCustomEntity("domhist_avalon_relay", // unique id
                "Avalon Relay", // name - if null, defaultName from custom_entities.json will be used
                "comm_relay", // type of object, defined in custom_entities.json
                "domhist"); // faction
        avalon_relay.setFixedLocation(1200f, -300f);
        //avalon_relay.setCircularOrbitPointingDown( domhist_lady,	/*avalon_star,*/ 295f, 1200, 580);
        


        SectorEntityToken avalon_station = system.addCustomEntity("domhist_annwn", "The Annwn Mob", "station_pirate_type", "pirates");
        // avalon_station.setCircularOrbitPointingDown(domhist_lady,	/*avalon_star,*/ 169, 4034f ,1401f);
        avalon_station.setFixedLocation(-4034f, -1401f);
        avalon_station.setCustomDescriptionId("domhist_station_annwyn_mob");
			  avalon_station.setInteractionImage("illustrations", "pirate_station");
        MarketAPI avalon_station_market = domhist_AddMarketplace.addMarketplace("pirates",
                                avalon_station, null,
                "The Annwn Mob",
                4,
                new ArrayList<String>(
                        Arrays.asList(
                                Conditions.POPULATION_4,
                                Conditions.OUTPOST
                        )
                ),
                new ArrayList<String>(
                        Arrays.asList(
                                Submarkets.GENERIC_MILITARY,
                                Submarkets.SUBMARKET_OPEN,
                                Submarkets.SUBMARKET_STORAGE,
                                Submarkets.SUBMARKET_BLACK
                        )
                ),
                new ArrayList<String>(
                        Arrays.asList(
                                Industries.POPULATION,
                                Industries.SPACEPORT,
                                Industries.MILITARYBASE,
                                Industries.BATTLESTATION_MID,
                                Industries.FUELPROD
                        )
                ),
                true,
                false);

        final String CUMBJORN_PORTRAIT = "graphics/portraits/domhist_cumbjorn.png";
        
        PersonAPI dh_pirate = createAdminist(avalon_station_market);
        dh_pirate.getStats().setSkillLevel(INDUSTRIAL_PLANNING, 2);
        //dh_pirate.getStats().setSkillLevel(PLANETARY_OPERATIONS, 1);
        dh_pirate.setPortraitSprite(CUMBJORN_PORTRAIT);
        dh_pirate.setPostId("fleetCommander");
        dh_pirate.setRankId("groundCaptain");
        dh_pirate.getName().setFirst("Cumbjorn");
        dh_pirate.getName().setLast("Cum");
        avalon_station_market.setSurveyLevel(FULL);
        
        
        //Custom Jump point Generation
        JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("domhist_avalon_jump_1", "Morgan Jump Point");
        jumpPoint1.setCircularOrbit( system.getEntityById("domhist_morgan"), 140, 1310, 183);
        jumpPoint1.setRelatedPlanet(avalon_1);
        system.addEntity(jumpPoint1);
        
        JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("domhist_avalon_jump_2", "Avalon Border Jump Point");
        jumpPoint2.setFixedLocation(-5100f, 1234f);
        system.addEntity(jumpPoint2);
        
        
        
        
        // add some extra low value planets
        
        PlanetAPI avalon_2 = system.addPlanet("domhist_tor",
        		avalon_star,
                "Tor",
                "rocky_ice",
                100f, //starting angle
                93f, //size
                1999f, // orbit radius
                1337f); // orbit time
        avalon_2.setFixedLocation(-507f, -6530f);
        
        system.addRingBand(avalon_2, "misc", "rings_ice0", 		256f, 0, Color.white, 172f, 250, 162f);
        
        
        PlanetAPI avalon_3 = system.addPlanet("domhist_nudd",
        		avalon_star,
                "Nudd",
                "ice_giant",
                100f, //starting angle
                313f, //size
                1999f, // orbit radius
                1337f); // orbit time
        avalon_3.setFixedLocation(-1321f, 5102f);
        
        
        // add some terrain
        
        system.addRingBand(avalon_1, "misc", "rings_dust0", 		256f, 0, Color.white, 160f, 1000, 70f);
		system.addRingBand(avalon_1, "misc", "rings_asteroids0", 256f, 1, Color.white, 156f, 1100, 90f);
        system.addRingBand(avalon_1, "misc", "rings_dust0", 		256f, 2, Color.white, 160f, 1200, 80f);
        
		system.addAsteroidBelt(avalon_1, 40, 1100, 120, 80, 110, Terrain.ASTEROID_BELT, null);
		
		SectorEntityToken avalon_astfield_1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
					700f, // min radius
					900f, // max radius
					29, // min asteroid count
					43, // max asteroid count
					4f, // min asteroid radius 
					16f, // max asteroid radius
					null)); // null for default name
		avalon_astfield_1.setFixedLocation(-1321f, 5102f);
		
		SectorEntityToken avalon_astfield_2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
					1600f, // min radius
					2300f, // max radius
					69, // min asteroid count
					108, // max asteroid count
					4f, // min asteroid radius 
					16f, // max asteroid radius
					null)); // null for default name
		avalon_astfield_2.setFixedLocation(-2321f, 702f);
		
		
		// add a debris field around the Lady
		
		DebrisFieldParams params = new DebrisFieldParams(
				333f, // field radius - should not go above 1000 for performance reasons
				0.5f, // density, visual - affects number of debris pieces
				10000000f, // duration in days 
				0f); // days the field will keep generating glowing pieces
		
		params.source = DebrisFieldSource.SALVAGE;
		params.baseSalvageXP = 250; // base XP for scavenging in field
		SectorEntityToken debris = Misc.addDebrisField(system, params, StarSystemGenerator.random);
		SalvageSpecialAssigner.assignSpecialForDebrisField(debris);
		
		// makes the debris field always visible on map/sensors and not give any xp or notification on being discovered
		debris.setSensorProfile(null);
		debris.setDiscoverable(null);
		debris.setCircularOrbit(domhist_lady, 0, 1, 4200);
		
		
		
		
        // generates hyperspace destinations for in-system jump points
        system.autogenerateHyperspaceJumpPoints(true, false);

        //Finally cleans up hyperspace
        cleanup(system);
    }

    //Shorthand function for cleaning up hyperspace
    private void cleanup(StarSystemAPI system){
        HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
        NebulaEditor editor = new NebulaEditor(plugin);
        float minRadius = plugin.getTileSize() * 2f;

        float radius = system.getMaxRadiusInHyperspace();
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0f, 360f);
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0f, 360f, 0.25f);
    }
}
