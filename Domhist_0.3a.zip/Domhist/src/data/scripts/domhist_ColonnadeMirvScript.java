package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.input.InputEventAPI;
import org.jetbrains.annotations.NotNull;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.Color;
import java.util.List;

public class domhist_ColonnadeMirvScript extends BaseEveryFrameCombatPlugin {

	private static final float TIMER = 1.2f; // the time the MIRV lasts before MIRVing
	
	private MissileAPI missile;
	private float timeCounter;
	
	public domhist_ColonnadeMirvScript(@NotNull MissileAPI missile) {
		this.missile = missile;
	}

	//Main advance method
	@Override
	public void advance(float amount, List<InputEventAPI> events) {
		//Sanity checks
		if (Global.getCombatEngine() == null) {
			return;
		}
		if (Global.getCombatEngine().isPaused()) {
			amount = 0f;
		}
		  CombatEngineAPI engine = Global.getCombatEngine();

		//Checks if our script should be removed from the combat engine
		if (missile == null || missile.didDamage() || missile.isFading() || !Global.getCombatEngine().isEntityInPlay(missile)) {
			engine.removePlugin(this);
			return;
		}
		
		
		 // debug particle spam
		/*
	 	Global.getCombatEngine().addSmoothParticle(missile.getLocation(),
				MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(32f, 80f)),
                12f, //size
                1.0f, //brightness
                0.5f, //duration
                new Color(160,120,50,55));
		 */
		
		//Ticks up our timer, and if over the detonation time, do the MIRV
		
		
		
		timeCounter+=amount;
		if (timeCounter > TIMER) {
			
			if (missile.getBaseDamageAmount() == 200f) {
				return;
				// little sanity check to prevent a funny meme bug that could potentially occur 
			}
			
			for (int i=0; i < 4; i++) {
              
				Vector2f vel = (Vector2f) (missile.getVelocity());
                Vector2f bombRandomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(1f, 45f));
                bombRandomVel.x += (vel.x * 1.1f);
                bombRandomVel.y += (vel.y * 1.1f);
                
                engine.spawnProjectile(missile.getWeapon().getShip(), missile.getWeapon(), "domhist_colonnade_dummy", missile.getLocation(), missile.getFacing(), bombRandomVel);
                
                Vector2f puffRandomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(4f, 20f));
            	engine.addSmokeParticle(missile.getLocation(), puffRandomVel, MathUtils.getRandomNumberInRange(20f, 40f), 0.8f, 0.8f, new Color(150,100,50,100));
                
                for (int j=0; j < 2; j++) {

                    float randomSize = MathUtils.getRandomNumberInRange(20f, 40f);
                    
                	Vector2f smokeRandomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(4f, 20f));
                	
                	engine.addNebulaSmokeParticle(missile.getLocation(),
                    		smokeRandomVel,
                    		randomSize, //size
                    		2.2f, //end mult
                    		0.5f, //ramp fraction
                    		0.75f, //full bright fraction
                    		0.9f, //duration
                    		new Color(150,100,50,100));
                	
                	smokeRandomVel.x += (vel.x * MathUtils.getRandomNumberInRange(1f, 1.4f));
                	smokeRandomVel.y += (vel.y * MathUtils.getRandomNumberInRange(1f, 1.4f));
                	
                    engine.addNebulaSmokeParticle(missile.getLocation(),
                    		smokeRandomVel,
                    		randomSize, //size
                    		2.2f, //end mult
                    		0.5f, //ramp fraction
                    		0.75f, //full bright fraction
                    		0.9f, //duration
                    		new Color(150,100,50,100));
                    /*
                    engine.addNebulaParticle(proj.getLocation(),
                    		smokeRandomVel,
                    		randomSize, //size
                    		2.2f, //end mult
                    		0.5f, //ramp fraction
                    		0.75f, //full bright fraction
                    		0.9f, //duration
                    		new Color(150,100,50,100),
                    		true);
                    */
                    
  				  for (int k=0; k < 2; k++) {
  	                
  					  float randomSize2 = MathUtils.getRandomNumberInRange(3f, 11f);
  	                
					  Vector2f randomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(15f, 61f));
		                
					  engine.addSmoothParticle(missile.getLocation(),
							  randomVel,
							  randomSize2, //size
							  1.0f, //brightness
							  0.65f, //duration
							  new Color(255,120,80,255));
							  
					  randomVel.x += (vel.x * MathUtils.getRandomNumberInRange(1f, 1.4f));
					  randomVel.y += (vel.y * MathUtils.getRandomNumberInRange(1f, 1.4f));
                
					  engine.addSmoothParticle(missile.getLocation(),
							  randomVel,
							  randomSize2, //size
							  1.0f, //brightness
							  0.65f, //duration
							  new Color(255,120,80,255));
				  }
                }
            }

            Global.getSoundPlayer().playSound("bomb_bay_fire", 1f, 1f, missile.getLocation(), missile.getVelocity());
            engine.removeEntity(missile);
			
		}
	}
}