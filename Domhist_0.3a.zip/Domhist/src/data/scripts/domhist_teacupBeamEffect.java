package data.scripts;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.IntervalUtil;

public class domhist_teacupBeamEffect implements BeamEffectPlugin {

	private IntervalUtil fireInterval = new IntervalUtil(0.9f, 0.9f);
	private IntervalUtil fxInterval = new IntervalUtil(0.1f, 0.1f);
	private boolean FIRED = false;
	
	public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
		
		float Dur = beam.getDamage().getDpsDuration();
		fxInterval.advance(Dur);
		
		 // spawn muzzle "smoke"
		if (fxInterval.intervalElapsed()) {
        	Vector2f smokeRandomVel = MathUtils.getRandomPointOnCircumference(beam.getWeapon().getShip().getVelocity(), MathUtils.getRandomNumberInRange(2f, 6f));
        	
        	engine.addNebulaSmokeParticle(beam.getFrom(),
            		smokeRandomVel,
            		MathUtils.getRandomNumberInRange(10f, 15f), //size
            		2.2f, //end mult
            		0.5f, //ramp fraction
            		0.6f, //full bright fraction
            		0.3f, //duration
            		new Color(225,220,215,125));
		}
		
		
		if (!FIRED ) {
			fireInterval.advance(amount);
			
			if (fireInterval.intervalElapsed()) {
				FIRED = true;

				WeaponAPI weapon = beam.getWeapon();
				Vector2f vel = weapon.getShip().getVelocity();
				Vector2f mLoc = weapon.getLocation();
				
				 // spawn the missile
				engine.spawnProjectile(weapon.getShip(), weapon, "domhist_teacup_missile", mLoc , weapon.getCurrAngle(), vel);
				
				 // spawn some smoke and sparks
				for (int j=0; j < 3; j++) {
					Vector2f puffRandomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(4f, 22f));
		        	engine.addSmokeParticle(mLoc, puffRandomVel, MathUtils.getRandomNumberInRange(20f, 40f), 0.8f, 0.8f, new Color(160,180,190,100));
		        	
		        	Vector2f sparkRandomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(17f, 60f));
		        	engine.addSmoothParticle(mLoc,
		        			sparkRandomVel,
		        			MathUtils.getRandomNumberInRange(4f, 11f), //size
							  1.0f, //brightness
							  0.4f, //duration
							  new Color(255,120,80,255));
				}
				
	        	 // play a sound
				Global.getSoundPlayer().playSound("swarmer_fire", 1f, 1f, beam.getFrom(), weapon.getShip().getVelocity());
				
			}
		}
	}
}