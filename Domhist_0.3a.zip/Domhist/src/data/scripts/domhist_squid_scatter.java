package data.scripts;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;

public class domhist_squid_scatter implements OnFireEffectPlugin {

	public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
    	
		Vector2f squidRandomVel = MathUtils.getRandomPointOnCircumference(weapon.getShip().getVelocity(), MathUtils.getRandomNumberInRange(1f, 50f));
    	DamagingProjectileAPI squidProj = (DamagingProjectileAPI) engine.spawnProjectile(weapon.getShip(), weapon, "domhist_squid_dummy", projectile.getLocation(), MathUtils.getRandomNumberInRange(0f, 360f), squidRandomVel);
    	squidProj.setAngularVelocity(MathUtils.getRandomNumberInRange(-60f, 60f));
    	
    	engine.removeEntity(projectile);
    }
}