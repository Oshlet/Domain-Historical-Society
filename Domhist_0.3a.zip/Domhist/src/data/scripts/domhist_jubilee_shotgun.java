package data.scripts;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;

public class domhist_jubilee_shotgun implements OnFireEffectPlugin {

    private static final Color FLASH_COLOR = new Color(250,200,120,225);
    
    public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
    	
    	ShipAPI ship = weapon.getShip();
        Vector2f ship_velocity = ship.getVelocity();
        Vector2f proj_location = projectile.getLocation();
        
        // explosion effect and some "core smoke"
        engine.spawnExplosion(proj_location, ship_velocity, FLASH_COLOR, 40f, 1.25f);
        
        for (int ex=0; ex < 3; ex++) {
            float angleEx = projectile.getFacing() + (-80 + (ex * 40));
            Vector2f offsetVelEx = MathUtils.getPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(2f, 5f), angleEx);
            
            Vector2f pointEx = MathUtils.getPointOnCircumference(proj_location, MathUtils.getRandomNumberInRange(3f, 8f), angleEx);
        	
        	engine.addNebulaSmokeParticle(MathUtils.getRandomPointInCircle(pointEx, 10f),
        		offsetVelEx,
        		MathUtils.getRandomNumberInRange(12f, 16f), //size
        		MathUtils.getRandomNumberInRange(1.5f, 1.8f), //end mult
        		0.4f, //ramp fraction
        		0.5f, //full bright fraction
        		MathUtils.getRandomNumberInRange(1.5f, 1.7f), //duration
        		new Color(125,100,90,75));
        }
        
        // play an additional sound, to blend the firesound, a "lazy workaround" until actual custom sounds happen.
        Global.getSoundPlayer().playSound("explosion_flak", 0.4f, 1.2f, proj_location, ship_velocity);
        
        // left/right/front particle jets
        for (int h=0; h < 30; h++) {
        	float angle1 = projectile.getFacing() + MathUtils.getRandomNumberInRange(80f, 90f);
            Vector2f offsetVel1 = MathUtils.getPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(6f, 60f), angle1);
            
            float angle2 = projectile.getFacing() - MathUtils.getRandomNumberInRange(80f, 90f);
            Vector2f offsetVel2 = MathUtils.getPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(6f, 60f), angle2);
            
            Vector2f point1 = MathUtils.getPointOnCircumference(proj_location, MathUtils.getRandomNumberInRange(2f, 20f), angle1);
            Vector2f point2 = MathUtils.getPointOnCircumference(proj_location, MathUtils.getRandomNumberInRange(2f, 20f), angle2);
            
            Global.getCombatEngine().addSmoothParticle(MathUtils.getRandomPointInCircle(point1, 4f),
            		offsetVel1,
            		MathUtils.getRandomNumberInRange(2f, 9f), //size
            		1.0f, //brightness
            		MathUtils.getRandomNumberInRange(1.3f, 1.5f), //duration
            		new Color(250,80,80,225));
            Global.getCombatEngine().addSmoothParticle(MathUtils.getRandomPointInCircle(point2, 4f),
            		offsetVel2,
            		MathUtils.getRandomNumberInRange(2f, 9f), //size
            		1.0f, //brightness
            		MathUtils.getRandomNumberInRange(1.3f, 1.5f), //duration
            		new Color(250,80,80,225));
            
            for (int h0=0; h0 < 2; h0++) {
                float angle3 = projectile.getFacing() + MathUtils.getRandomNumberInRange(-7.5f, 7.5f);
                Vector2f offsetVel3 = MathUtils.getPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(9f, 90f), angle3);

                Vector2f point3 = MathUtils.getPointOnCircumference(proj_location, MathUtils.getRandomNumberInRange(3f, 30f), angle3);

                Global.getCombatEngine().addSmoothParticle(MathUtils.getRandomPointInCircle(point3, 4f),
                		offsetVel3,
                		MathUtils.getRandomNumberInRange(2f, 9f), //size
                		1.0f, //brightness
                		MathUtils.getRandomNumberInRange(1.3f, 1.5f), //duration
                		new Color(250,80,80,225));
            }
        }
        
        // left/right/front nebula "jets"
        for (int h2=0; h2 < 10; h2++) {
        	float angle1 = projectile.getFacing() + MathUtils.getRandomNumberInRange(83f, 87f);
            Vector2f offsetVel1 = MathUtils.getPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(2f, 25f), angle1);
            
            float angle2 = projectile.getFacing() - MathUtils.getRandomNumberInRange(83f, 87f);
            Vector2f offsetVel2 = MathUtils.getPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(2f, 25f), angle2);
            
            Vector2f point1 = MathUtils.getPointOnCircumference(proj_location, MathUtils.getRandomNumberInRange(1f, 10f), angle1);
            Vector2f point2 = MathUtils.getPointOnCircumference(proj_location, MathUtils.getRandomNumberInRange(1f, 10f), angle2);
            
            engine.addNebulaSmokeParticle(MathUtils.getRandomPointInCircle(point1, 3f),
            		offsetVel1,
            		MathUtils.getRandomNumberInRange(9f, 12f), //size
            		MathUtils.getRandomNumberInRange(1.4f, 1.7f), //end mult
            		0.4f, //ramp fraction
            		0.5f, //full bright fraction
            		MathUtils.getRandomNumberInRange(1.4f, 1.6f), //duration
            		new Color(125,100,90,75));
            engine.addNebulaSmokeParticle(MathUtils.getRandomPointInCircle(point2, 3f),
            		offsetVel2,
            		MathUtils.getRandomNumberInRange(9f, 12f), //size
            		MathUtils.getRandomNumberInRange(1.4f, 1.7f), //end mult
            		0.4f, //ramp fraction
            		0.5f, //full bright fraction
            		MathUtils.getRandomNumberInRange(1.4f, 1.6f), //duration
            		new Color(125,100,90,75));
            
            for (int h3=0; h3 < 2; h3++) {
                float angle3 = projectile.getFacing() + MathUtils.getRandomNumberInRange(-5f, 5f);
                Vector2f offsetVel3 = MathUtils.getPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(3f, 40f), angle3);

                Vector2f point3 = MathUtils.getPointOnCircumference(proj_location, MathUtils.getRandomNumberInRange(2f, 15f), angle3);
                
                engine.addNebulaSmokeParticle(MathUtils.getRandomPointInCircle(point3, 3f),
                		offsetVel3,
                		MathUtils.getRandomNumberInRange(9f, 12f), //size
                		MathUtils.getRandomNumberInRange(1.4f, 1.7f), //end mult
                		0.4f, //ramp fraction
                		0.5f, //full bright fraction
                		MathUtils.getRandomNumberInRange(1.4f, 1.6f), //duration
                		new Color(125,100,90,75));
            }
        }
        
        // particle "burst"
        for (int h4=0; h4 < 160; h4++) {
        	float angle0 = projectile.getFacing() + MathUtils.getRandomNumberInRange(-84f, 84f);
            Vector2f offsetVel0 = MathUtils.getPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(15f, 125f), angle0);
            
            Vector2f point0 = MathUtils.getPointOnCircumference(proj_location, MathUtils.getRandomNumberInRange(3f, 30f), angle0);
            
            Global.getCombatEngine().addSmoothParticle(MathUtils.getRandomPointInCircle(point0, 5f),
            		offsetVel0,
            		MathUtils.getRandomNumberInRange(2f, 5f), //size
            		MathUtils.getRandomNumberInRange(0.65f, 0.95f), //brightness
            		MathUtils.getRandomNumberInRange(0.6f, 0.75f), //duration
            		new Color(250,200,120,255));
        }
        
        // fire the sub-projectiles
        for (int i=0; i < 3; i++) {
        	Vector2f jubileeRandomVel1 = MathUtils.getRandomPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(1f, 30f));
        	engine.spawnProjectile(ship, weapon, "domhist_jubilee_dummy_1", proj_location, projectile.getFacing(), jubileeRandomVel1);
        }
            
        for (int j=0; j < 2; j++) {
        	Vector2f jubileeRandomVel2 = MathUtils.getRandomPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(1f, 20f));
        	engine.spawnProjectile(ship, weapon, "domhist_jubilee_dummy_2", proj_location, projectile.getFacing(), jubileeRandomVel2);
        }
        
    	Vector2f jubileeRandomVel3 = MathUtils.getRandomPointOnCircumference(ship_velocity, MathUtils.getRandomNumberInRange(1f, 10f));
    	engine.spawnProjectile(ship, weapon, "domhist_jubilee_dummy_3", proj_location, projectile.getFacing(), jubileeRandomVel3);
    }
}