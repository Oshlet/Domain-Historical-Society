package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.input.InputEventAPI;
import org.jetbrains.annotations.NotNull;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.Color;
import java.util.List;

public class domhist_SardineDrunkScript extends BaseEveryFrameCombatPlugin {

	private static final float TIMER = 0.05f; // the time between drunk "sway steps"
	private static final float SWAY = 4.5f; // the strength of the drunk "sway"
	
	private MissileAPI missile;
	private float timeCounter;
	
	public domhist_SardineDrunkScript(@NotNull MissileAPI missile) {
		this.missile = missile;
	}

	//Main advance method
	@Override
	public void advance(float amount, List<InputEventAPI> events) {
		//Sanity checks
		if (Global.getCombatEngine() == null) {
			return;
		}
		if (Global.getCombatEngine().isPaused()) {
			amount = 0f;
		}
		  CombatEngineAPI engine = Global.getCombatEngine();

		//Checks if our script should be removed from the combat engine
		if (missile == null || missile.didDamage() || missile.isFading() || !Global.getCombatEngine().isEntityInPlay(missile)) {
			engine.removePlugin(this);
			return;
		}
		
		//Ticks up our timer, and does the wiggle+fx
		timeCounter+=amount;
		if (timeCounter > TIMER) {
			
			float facing = missile.getFacing();
			facing += MathUtils.getRandomNumberInRange(-SWAY, SWAY);
			missile.setFacing(facing);
			
			Vector2f vel = new Vector2f();
			vel.x += missile.getVelocity().x;
			vel.y += missile.getVelocity().y;
			
			Vector2f puffRandomVel1 = MathUtils.getRandomPointOnCircumference((Vector2f) vel.scale(MathUtils.getRandomNumberInRange(0.4f, 0.6f)), MathUtils.getRandomNumberInRange(4f, 20f));
			Vector2f puffRandomVel2 = MathUtils.getRandomPointOnCircumference((Vector2f) vel.scale(MathUtils.getRandomNumberInRange(0.4f, 0.6f)), MathUtils.getRandomNumberInRange(4f, 20f));
			
			engine.addSmokeParticle(missile.getLocation(), puffRandomVel1, MathUtils.getRandomNumberInRange(7f, 14f), 0.7f, 0.3f, new Color(105,100,95,75));
            engine.addNebulaSmokeParticle(missile.getLocation(),
            		puffRandomVel2,
            		MathUtils.getRandomNumberInRange(8f, 16f), //size
            		2.0f, //end mult
            		0.5f, //ramp fraction
            		0.5f, //full bright fraction
            		0.33f, //duration
            		new Color(105,100,95,75));
                
			timeCounter -= TIMER; // so you always get the rate the time truly suggests, regardless of overflow
		}
	}
}