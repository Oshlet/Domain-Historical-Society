package data.scripts;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.ProximityExplosionEffect;

public class domhist_ChannelOnSubBlastEffect implements ProximityExplosionEffect {
	
	public void onExplosion(DamagingProjectileAPI explosion, DamagingProjectileAPI originalProjectile) {
		
		for (int j=0; j < 23; j++) {
			Vector2f randomVel2 = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(15f, 50f));
			
			float randomSize = MathUtils.getRandomNumberInRange(2f, 7f);
			Global.getCombatEngine().addSmoothParticle(explosion.getLocation(),
					randomVel2,
					randomSize, //size
					0.8f, //brightness
					1.2f, //duration
					new Color(25,165,50,200));
		}

		Global.getCombatEngine().addSmoothParticle(explosion.getLocation(),
				explosion.getVelocity(),
				81f, //size
				0.7f, //brightness
				1.5f, //duration
				new Color(60,200,20,160));
	}
}



