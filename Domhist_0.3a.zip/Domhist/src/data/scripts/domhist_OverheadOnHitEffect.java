package data.scripts;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;

public class domhist_OverheadOnHitEffect implements OnHitEffectPlugin {

	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
		if ((float) Math.random() > 0.6f && !shieldHit && target instanceof ShipAPI) {
			
			float emp = projectile.getEmpAmount();
			float dam = projectile.getDamageAmount();
			
			engine.spawnEmpArc(projectile.getSource(), point, target, target,
							   DamageType.FRAGMENTATION, 
							   dam,
							   emp, // emp 
							   100000f, // max range 
							   "tachyon_lance_emp_impact",
							   20f, // thickness
							   new Color(25,150,155,255),
							   new Color(255,255,255,255)
							   );
		}
		
		for (int i=0; i < 3; i++) {
			Vector2f randomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(35f, 65f));
			Vector2f sparkVel = target.getVelocity();
			randomVel.x += sparkVel.x;
			randomVel.y += sparkVel.y;
			
			float randomSize = MathUtils.getRandomNumberInRange(3f, 9f);
			Global.getCombatEngine().addSmoothParticle(point,
				randomVel,
				randomSize, //size
				0.9f, //brightness
				0.7f, //duration
				new Color(25,155,150,255));
        }
	}
}
