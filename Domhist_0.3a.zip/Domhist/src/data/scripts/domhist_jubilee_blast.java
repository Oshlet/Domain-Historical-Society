package data.scripts;

import java.awt.Color;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;

public class domhist_jubilee_blast implements OnHitEffectPlugin {

	private static final Color COLOR_P = new Color(240,160,80,180);
	private static final Color COLOR_X = new Color(250,200,120,255);
	
	private static final Color COLOR_D_C = new Color(165,155,150,255);
	private static final Color COLOR_D_F = new Color(210,90,60,255);
	
	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
		
		float blastDamage = projectile.getDamageAmount();
		DamagingExplosionSpec blast = new DamagingExplosionSpec(0.2f,
                110f,
                60f,
                blastDamage,
                blastDamage * 0.6f,
                CollisionClass.PROJECTILE_FF,
                CollisionClass.PROJECTILE_FIGHTER,
                5f,
                5f,
                1f, // 1.2
                120,
                COLOR_P,
                COLOR_X);
        blast.setDamageType(DamageType.ENERGY);
        blast.setShowGraphic(true);
        blast.setDetailedExplosionFlashColorCore(COLOR_D_C);
        blast.setDetailedExplosionFlashColorFringe(COLOR_D_F);
        blast.setUseDetailedExplosion(true);
        blast.setDetailedExplosionRadius(120f);
        blast.setDetailedExplosionFlashRadius(250f);
        blast.setDetailedExplosionFlashDuration(0.5f);
        
        engine.spawnDamagingExplosion(blast,projectile.getSource(),point,false);
        
		Global.getSoundPlayer().playSound("system_canister_flak_explosion", 0.65f, 1.0f, point, target.getVelocity());
	}
}
