package data.scripts;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;

public class domhist_sunderWeaponScript implements EveryFrameWeaponEffectPlugin {

	@Override
	public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
		
		// a "hack" that forcibly sets weapon animation frames, to show whether or not there is a power cell in the weapon
		
		if (weapon.getCooldownRemaining() > 0f) {
			weapon.getAnimation().setFrame(1);
		} else {
			weapon.getAnimation().setFrame(0);
		}
		
		if (weapon.getAmmo() == 0) {
			weapon.getAnimation().setFrame(1);
		}
		
		if (weapon.isFiring()) {
			weapon.getAnimation().setFrame(0);
		}
		
	}
  }