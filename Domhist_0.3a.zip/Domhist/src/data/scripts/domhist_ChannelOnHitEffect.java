package data.scripts;

import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.Misc;

public class domhist_ChannelOnHitEffect implements OnHitEffectPlugin {

	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {

		for (int i=0; i < 7; i++) {
			float arcRandom = MathUtils.getRandomNumberInRange(-180, 180);
			float rangeRandom = MathUtils.getRandomNumberInRange(0.3f, 1.2f);
			Vector2f direction = Misc.getUnitVectorAtDegreeAngle(projectile.getFacing() + arcRandom);
			Vector2f origin = new Vector2f(point.x + direction.x * 100 * rangeRandom, point.y + direction.y * -100 * rangeRandom);
			Vector2f randomVel = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(50f, 100f));
			
			engine.spawnProjectile(projectile.getSource(),
                    projectile.getWeapon(), "domhist_channel_cluster_dummy",
                     origin,
                     projectile.getFacing(),
                     randomVel);
        
			for (int j=0; j < 5; j++) {
				Vector2f randomVel2 = MathUtils.getRandomPointOnCircumference(null, MathUtils.getRandomNumberInRange(30f, 64f));
				Vector2f sparkVel = target.getVelocity();
				randomVel2.x += sparkVel.x;
				randomVel2.y += sparkVel.y;
			
				float randomSize = MathUtils.getRandomNumberInRange(4f, 9f);
				Global.getCombatEngine().addSmoothParticle(origin,
						randomVel2,
						randomSize, //size
						0.8f, //brightness
						0.6f, //duration
						new Color(50,155,25,200));
			}
		}

		if (!shieldHit && target instanceof ShipAPI) {
			
			float emp = projectile.getEmpAmount() / 6f;
			float dam = projectile.getDamageAmount() / 8f;
			
			int arc_num = MathUtils.getRandomNumberInRange(2,5);
			for (int i = 0; i < arc_num; i++) {
			engine.spawnEmpArc(projectile.getSource(), point, target, target,
							   DamageType.ENERGY, 
							   dam,
							   emp, // emp 
							   100000f, // max range 
							   "tachyon_lance_emp_impact",
							   20f, // thickness
							   new Color(155,50,25,255),
							   new Color(255,255,255,255)
							   );
			}
		}
	}
}
